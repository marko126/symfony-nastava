<?php

/* @Twig/Exception/exception.rdf.twig */
class __TwigTemplate_a6b200f73c52419e1fc69c6a13007504f530b48901dfd5f644068c984250d703 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bb48328de41e066192288239de64893766e95c0977e8baae9c8601684e8353cd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bb48328de41e066192288239de64893766e95c0977e8baae9c8601684e8353cd->enter($__internal_bb48328de41e066192288239de64893766e95c0977e8baae9c8601684e8353cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        $__internal_4842a78de515c03699a18d8a6cf4877545d1766cb4e20f806314f6af224884a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4842a78de515c03699a18d8a6cf4877545d1766cb4e20f806314f6af224884a8->enter($__internal_4842a78de515c03699a18d8a6cf4877545d1766cb4e20f806314f6af224884a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "@Twig/Exception/exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_bb48328de41e066192288239de64893766e95c0977e8baae9c8601684e8353cd->leave($__internal_bb48328de41e066192288239de64893766e95c0977e8baae9c8601684e8353cd_prof);

        
        $__internal_4842a78de515c03699a18d8a6cf4877545d1766cb4e20f806314f6af224884a8->leave($__internal_4842a78de515c03699a18d8a6cf4877545d1766cb4e20f806314f6af224884a8_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
", "@Twig/Exception/exception.rdf.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.rdf.twig");
    }
}
