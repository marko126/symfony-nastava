<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_c92498ce9ae689a89c5c32486615c63d71326cc2fee840e3f9301fbb2b377c63 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e8a6b264cb5ed41e3bf95fa2cb451f3c796889011a63d6ba93c75524602d3b6f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e8a6b264cb5ed41e3bf95fa2cb451f3c796889011a63d6ba93c75524602d3b6f->enter($__internal_e8a6b264cb5ed41e3bf95fa2cb451f3c796889011a63d6ba93c75524602d3b6f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_9ab389ee651b538d8cf231be826054eb1a30234b4f64480b7e0aede5cddba6d9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9ab389ee651b538d8cf231be826054eb1a30234b4f64480b7e0aede5cddba6d9->enter($__internal_9ab389ee651b538d8cf231be826054eb1a30234b4f64480b7e0aede5cddba6d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_e8a6b264cb5ed41e3bf95fa2cb451f3c796889011a63d6ba93c75524602d3b6f->leave($__internal_e8a6b264cb5ed41e3bf95fa2cb451f3c796889011a63d6ba93c75524602d3b6f_prof);

        
        $__internal_9ab389ee651b538d8cf231be826054eb1a30234b4f64480b7e0aede5cddba6d9->leave($__internal_9ab389ee651b538d8cf231be826054eb1a30234b4f64480b7e0aede5cddba6d9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_enctype.html.php");
    }
}
