<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_bad00da722ca787bc97b7c3152d4de17343c777e34609798f870384ef623170a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f55cf818a676485064c9113f9950ba47f5ace0576263709f7e70b3f9879b0231 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f55cf818a676485064c9113f9950ba47f5ace0576263709f7e70b3f9879b0231->enter($__internal_f55cf818a676485064c9113f9950ba47f5ace0576263709f7e70b3f9879b0231_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_5bafd4e6ee15609fca3fea18ca46cf8fc1eae75a7b6699d373ddde49b069b1eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5bafd4e6ee15609fca3fea18ca46cf8fc1eae75a7b6699d373ddde49b069b1eb->enter($__internal_5bafd4e6ee15609fca3fea18ca46cf8fc1eae75a7b6699d373ddde49b069b1eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_f55cf818a676485064c9113f9950ba47f5ace0576263709f7e70b3f9879b0231->leave($__internal_f55cf818a676485064c9113f9950ba47f5ace0576263709f7e70b3f9879b0231_prof);

        
        $__internal_5bafd4e6ee15609fca3fea18ca46cf8fc1eae75a7b6699d373ddde49b069b1eb->leave($__internal_5bafd4e6ee15609fca3fea18ca46cf8fc1eae75a7b6699d373ddde49b069b1eb_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_27cc86959458c1af6ebd7b57e00acf67f810367ed20e271432a6375b6a2aa0dd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_27cc86959458c1af6ebd7b57e00acf67f810367ed20e271432a6375b6a2aa0dd->enter($__internal_27cc86959458c1af6ebd7b57e00acf67f810367ed20e271432a6375b6a2aa0dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_5a02f64db762af6e734aab49f5a066cf580d74c27de3c37b2fce297fbb36aaea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a02f64db762af6e734aab49f5a066cf580d74c27de3c37b2fce297fbb36aaea->enter($__internal_5a02f64db762af6e734aab49f5a066cf580d74c27de3c37b2fce297fbb36aaea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_5a02f64db762af6e734aab49f5a066cf580d74c27de3c37b2fce297fbb36aaea->leave($__internal_5a02f64db762af6e734aab49f5a066cf580d74c27de3c37b2fce297fbb36aaea_prof);

        
        $__internal_27cc86959458c1af6ebd7b57e00acf67f810367ed20e271432a6375b6a2aa0dd->leave($__internal_27cc86959458c1af6ebd7b57e00acf67f810367ed20e271432a6375b6a2aa0dd_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
