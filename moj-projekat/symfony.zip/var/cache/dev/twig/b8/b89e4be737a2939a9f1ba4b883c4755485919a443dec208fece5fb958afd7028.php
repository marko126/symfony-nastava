<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_592d11243a77b870dce815fb2f0f7347885dd26b5d8b473f2ff35c8b529a892a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f59758e3b767dca850f6c6baa8aad61cdd320cd3f58b8c341507a267497787fd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f59758e3b767dca850f6c6baa8aad61cdd320cd3f58b8c341507a267497787fd->enter($__internal_f59758e3b767dca850f6c6baa8aad61cdd320cd3f58b8c341507a267497787fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        $__internal_51bab8d796400b18e4ecfc0e991063901a1cae388a363b0fe8df91cff993b5cd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_51bab8d796400b18e4ecfc0e991063901a1cae388a363b0fe8df91cff993b5cd->enter($__internal_51bab8d796400b18e4ecfc0e991063901a1cae388a363b0fe8df91cff993b5cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_f59758e3b767dca850f6c6baa8aad61cdd320cd3f58b8c341507a267497787fd->leave($__internal_f59758e3b767dca850f6c6baa8aad61cdd320cd3f58b8c341507a267497787fd_prof);

        
        $__internal_51bab8d796400b18e4ecfc0e991063901a1cae388a363b0fe8df91cff993b5cd->leave($__internal_51bab8d796400b18e4ecfc0e991063901a1cae388a363b0fe8df91cff993b5cd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
", "@Framework/Form/form_widget_compound.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget_compound.html.php");
    }
}
