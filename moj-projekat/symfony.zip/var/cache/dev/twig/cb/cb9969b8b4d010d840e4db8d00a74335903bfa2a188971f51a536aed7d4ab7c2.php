<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_d764d199f3b76b96c96319241c74dbf9783e80f23ad3c4272876bd5361eeacc3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c7826adf377bfc07797d6539f418fa76a8063992f511cbb338f2ebd94575484e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c7826adf377bfc07797d6539f418fa76a8063992f511cbb338f2ebd94575484e->enter($__internal_c7826adf377bfc07797d6539f418fa76a8063992f511cbb338f2ebd94575484e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $__internal_4a2377f685e5d4435b3d2992c4a036e9a47a5429412d960beed1ac5ed245a358 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4a2377f685e5d4435b3d2992c4a036e9a47a5429412d960beed1ac5ed245a358->enter($__internal_4a2377f685e5d4435b3d2992c4a036e9a47a5429412d960beed1ac5ed245a358_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c7826adf377bfc07797d6539f418fa76a8063992f511cbb338f2ebd94575484e->leave($__internal_c7826adf377bfc07797d6539f418fa76a8063992f511cbb338f2ebd94575484e_prof);

        
        $__internal_4a2377f685e5d4435b3d2992c4a036e9a47a5429412d960beed1ac5ed245a358->leave($__internal_4a2377f685e5d4435b3d2992c4a036e9a47a5429412d960beed1ac5ed245a358_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_f7c0e8cc75d1436efca59d729b4991adaf2d98b6f6627376c1552d5e8014cfc0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f7c0e8cc75d1436efca59d729b4991adaf2d98b6f6627376c1552d5e8014cfc0->enter($__internal_f7c0e8cc75d1436efca59d729b4991adaf2d98b6f6627376c1552d5e8014cfc0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_56c671593f654cfb2803f59f36e8b208b3b89a3910880da4e4c957944afd4eaa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_56c671593f654cfb2803f59f36e8b208b3b89a3910880da4e4c957944afd4eaa->enter($__internal_56c671593f654cfb2803f59f36e8b208b3b89a3910880da4e4c957944afd4eaa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_56c671593f654cfb2803f59f36e8b208b3b89a3910880da4e4c957944afd4eaa->leave($__internal_56c671593f654cfb2803f59f36e8b208b3b89a3910880da4e4c957944afd4eaa_prof);

        
        $__internal_f7c0e8cc75d1436efca59d729b4991adaf2d98b6f6627376c1552d5e8014cfc0->leave($__internal_f7c0e8cc75d1436efca59d729b4991adaf2d98b6f6627376c1552d5e8014cfc0_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_bec71630d7f41c10f9807d83650c0862ec29d32934cddff6e97b34d4cd72e62a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bec71630d7f41c10f9807d83650c0862ec29d32934cddff6e97b34d4cd72e62a->enter($__internal_bec71630d7f41c10f9807d83650c0862ec29d32934cddff6e97b34d4cd72e62a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d46ac58faa89d75d2b9c2952eaa483b3905b132b1e547fcb1587c151df0e8bca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d46ac58faa89d75d2b9c2952eaa483b3905b132b1e547fcb1587c151df0e8bca->enter($__internal_d46ac58faa89d75d2b9c2952eaa483b3905b132b1e547fcb1587c151df0e8bca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_d46ac58faa89d75d2b9c2952eaa483b3905b132b1e547fcb1587c151df0e8bca->leave($__internal_d46ac58faa89d75d2b9c2952eaa483b3905b132b1e547fcb1587c151df0e8bca_prof);

        
        $__internal_bec71630d7f41c10f9807d83650c0862ec29d32934cddff6e97b34d4cd72e62a->leave($__internal_bec71630d7f41c10f9807d83650c0862ec29d32934cddff6e97b34d4cd72e62a_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
