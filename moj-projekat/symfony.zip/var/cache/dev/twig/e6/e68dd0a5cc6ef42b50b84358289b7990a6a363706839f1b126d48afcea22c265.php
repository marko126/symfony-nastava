<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_ad5d154f2a2152ad703bc00d2103009a4ecb6cf1bb8b936d3937648785031c86 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c215432a4f0164f93214dd3194b179f2e9d5de4e44f135b9662884c71125ea09 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c215432a4f0164f93214dd3194b179f2e9d5de4e44f135b9662884c71125ea09->enter($__internal_c215432a4f0164f93214dd3194b179f2e9d5de4e44f135b9662884c71125ea09_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        $__internal_b17f7054c6312de29a890fec03192c39f5253f8503bdc1fa36d1a67f083e5275 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b17f7054c6312de29a890fec03192c39f5253f8503bdc1fa36d1a67f083e5275->enter($__internal_b17f7054c6312de29a890fec03192c39f5253f8503bdc1fa36d1a67f083e5275_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_c215432a4f0164f93214dd3194b179f2e9d5de4e44f135b9662884c71125ea09->leave($__internal_c215432a4f0164f93214dd3194b179f2e9d5de4e44f135b9662884c71125ea09_prof);

        
        $__internal_b17f7054c6312de29a890fec03192c39f5253f8503bdc1fa36d1a67f083e5275->leave($__internal_b17f7054c6312de29a890fec03192c39f5253f8503bdc1fa36d1a67f083e5275_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
", "@Framework/Form/attributes.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\attributes.html.php");
    }
}
