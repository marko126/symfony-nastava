<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_a51e5bdcaab6110e1cad8a6056ab34c5b28d0f996afa8ae0c381de517e617507 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1155e6194900fecd7afd024e6aa9e854ff2d0741af4e68d8a7f605b7b94f372e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1155e6194900fecd7afd024e6aa9e854ff2d0741af4e68d8a7f605b7b94f372e->enter($__internal_1155e6194900fecd7afd024e6aa9e854ff2d0741af4e68d8a7f605b7b94f372e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        $__internal_810381829aca97934414c2f26bce109fe4cd7f86cbc6a7b6d5ffc7134c43e1fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_810381829aca97934414c2f26bce109fe4cd7f86cbc6a7b6d5ffc7134c43e1fe->enter($__internal_810381829aca97934414c2f26bce109fe4cd7f86cbc6a7b6d5ffc7134c43e1fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_1155e6194900fecd7afd024e6aa9e854ff2d0741af4e68d8a7f605b7b94f372e->leave($__internal_1155e6194900fecd7afd024e6aa9e854ff2d0741af4e68d8a7f605b7b94f372e_prof);

        
        $__internal_810381829aca97934414c2f26bce109fe4cd7f86cbc6a7b6d5ffc7134c43e1fe->leave($__internal_810381829aca97934414c2f26bce109fe4cd7f86cbc6a7b6d5ffc7134c43e1fe_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\radio_widget.html.php");
    }
}
