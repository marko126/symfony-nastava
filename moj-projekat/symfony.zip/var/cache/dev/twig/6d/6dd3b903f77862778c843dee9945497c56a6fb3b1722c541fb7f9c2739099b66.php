<?php

/* TwigBundle:Exception:error.txt.twig */
class __TwigTemplate_aadd18be9fac7892cc2fa63177d49b4aaf1ebb9eb47e56d3f5a560ad39294568 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_03582e1ee62af190a25e5fd2a9ca996f4b4902b98f18fb73ba38137470a0b396 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_03582e1ee62af190a25e5fd2a9ca996f4b4902b98f18fb73ba38137470a0b396->enter($__internal_03582e1ee62af190a25e5fd2a9ca996f4b4902b98f18fb73ba38137470a0b396_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        $__internal_07fc3f52fc989df4ac4dc5c4633c2e6f25516b471bbecf985baa04067b16fed5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_07fc3f52fc989df4ac4dc5c4633c2e6f25516b471bbecf985baa04067b16fed5->enter($__internal_07fc3f52fc989df4ac4dc5c4633c2e6f25516b471bbecf985baa04067b16fed5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code"));
        echo " ";
        echo (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text"));
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_03582e1ee62af190a25e5fd2a9ca996f4b4902b98f18fb73ba38137470a0b396->leave($__internal_03582e1ee62af190a25e5fd2a9ca996f4b4902b98f18fb73ba38137470a0b396_prof);

        
        $__internal_07fc3f52fc989df4ac4dc5c4633c2e6f25516b471bbecf985baa04067b16fed5->leave($__internal_07fc3f52fc989df4ac4dc5c4633c2e6f25516b471bbecf985baa04067b16fed5_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 4,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Oops! An Error Occurred
=======================

The server returned a \"{{ status_code }} {{ status_text }}\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
", "TwigBundle:Exception:error.txt.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.txt.twig");
    }
}
