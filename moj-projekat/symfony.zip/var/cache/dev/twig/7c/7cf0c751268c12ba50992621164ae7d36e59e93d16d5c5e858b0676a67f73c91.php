<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_03950a0a915bd9befa65677f9ee681c507039a3f379b1480d1fad8612bbd90e6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a80e65e952dfe37e68922eb562fd2aab6ff3fc8c645df580218f62338662bf76 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a80e65e952dfe37e68922eb562fd2aab6ff3fc8c645df580218f62338662bf76->enter($__internal_a80e65e952dfe37e68922eb562fd2aab6ff3fc8c645df580218f62338662bf76_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        $__internal_60e9c39912a21453323453e8ca0a9824526c01e4e58abf7e3a87fed2495f98da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60e9c39912a21453323453e8ca0a9824526c01e4e58abf7e3a87fed2495f98da->enter($__internal_60e9c39912a21453323453e8ca0a9824526c01e4e58abf7e3a87fed2495f98da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_a80e65e952dfe37e68922eb562fd2aab6ff3fc8c645df580218f62338662bf76->leave($__internal_a80e65e952dfe37e68922eb562fd2aab6ff3fc8c645df580218f62338662bf76_prof);

        
        $__internal_60e9c39912a21453323453e8ca0a9824526c01e4e58abf7e3a87fed2495f98da->leave($__internal_60e9c39912a21453323453e8ca0a9824526c01e4e58abf7e3a87fed2495f98da_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
", "@Framework/Form/choice_widget_expanded.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_widget_expanded.html.php");
    }
}
