<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_da4b8f10f78fe5bc39367f4f7c2cd4a0515506a72fe6b412b6f17fc256b30c6b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ce9fe2d0bbd5d1e1fcbebf47b511469b7c5d2fb31f79b3393aea8c4b56f34e1e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ce9fe2d0bbd5d1e1fcbebf47b511469b7c5d2fb31f79b3393aea8c4b56f34e1e->enter($__internal_ce9fe2d0bbd5d1e1fcbebf47b511469b7c5d2fb31f79b3393aea8c4b56f34e1e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_495df3a3b8fd780f963eef30d64d1be140f252a03e8b0e6d40b265dceeeedc18 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_495df3a3b8fd780f963eef30d64d1be140f252a03e8b0e6d40b265dceeeedc18->enter($__internal_495df3a3b8fd780f963eef30d64d1be140f252a03e8b0e6d40b265dceeeedc18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_ce9fe2d0bbd5d1e1fcbebf47b511469b7c5d2fb31f79b3393aea8c4b56f34e1e->leave($__internal_ce9fe2d0bbd5d1e1fcbebf47b511469b7c5d2fb31f79b3393aea8c4b56f34e1e_prof);

        
        $__internal_495df3a3b8fd780f963eef30d64d1be140f252a03e8b0e6d40b265dceeeedc18->leave($__internal_495df3a3b8fd780f963eef30d64d1be140f252a03e8b0e6d40b265dceeeedc18_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\textarea_widget.html.php");
    }
}
