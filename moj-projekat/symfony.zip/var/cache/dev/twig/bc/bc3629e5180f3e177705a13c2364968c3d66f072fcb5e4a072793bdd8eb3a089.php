<?php

/* WebProfilerBundle:Profiler:open.html.twig */
class __TwigTemplate_2ba531255f9c9826ac69a861a4e7b2032b7f1656537ac34d7a9979d357383bb9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "WebProfilerBundle:Profiler:open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f39d44b407d9438c8d0fad844c245ba8658ab152b74581ee6a76c2d70d49451b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f39d44b407d9438c8d0fad844c245ba8658ab152b74581ee6a76c2d70d49451b->enter($__internal_f39d44b407d9438c8d0fad844c245ba8658ab152b74581ee6a76c2d70d49451b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $__internal_a7380e78ea02a6bf06e2864d2e54feecb3f87b3bebeed8b8800aae8454b9c200 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a7380e78ea02a6bf06e2864d2e54feecb3f87b3bebeed8b8800aae8454b9c200->enter($__internal_a7380e78ea02a6bf06e2864d2e54feecb3f87b3bebeed8b8800aae8454b9c200_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f39d44b407d9438c8d0fad844c245ba8658ab152b74581ee6a76c2d70d49451b->leave($__internal_f39d44b407d9438c8d0fad844c245ba8658ab152b74581ee6a76c2d70d49451b_prof);

        
        $__internal_a7380e78ea02a6bf06e2864d2e54feecb3f87b3bebeed8b8800aae8454b9c200->leave($__internal_a7380e78ea02a6bf06e2864d2e54feecb3f87b3bebeed8b8800aae8454b9c200_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_4da8fb7a7dae76d8aba6ac8f61d38c59c47bb2a5e469cea9a27b0d6532f45968 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4da8fb7a7dae76d8aba6ac8f61d38c59c47bb2a5e469cea9a27b0d6532f45968->enter($__internal_4da8fb7a7dae76d8aba6ac8f61d38c59c47bb2a5e469cea9a27b0d6532f45968_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_41984d9f157658e124a664734dc9d5db5424e9238d24e4e8a47b89d6bee158a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_41984d9f157658e124a664734dc9d5db5424e9238d24e4e8a47b89d6bee158a9->enter($__internal_41984d9f157658e124a664734dc9d5db5424e9238d24e4e8a47b89d6bee158a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_41984d9f157658e124a664734dc9d5db5424e9238d24e4e8a47b89d6bee158a9->leave($__internal_41984d9f157658e124a664734dc9d5db5424e9238d24e4e8a47b89d6bee158a9_prof);

        
        $__internal_4da8fb7a7dae76d8aba6ac8f61d38c59c47bb2a5e469cea9a27b0d6532f45968->leave($__internal_4da8fb7a7dae76d8aba6ac8f61d38c59c47bb2a5e469cea9a27b0d6532f45968_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_b971df4a482d14ae87d69399b8147ff1517c5a1f5f63bd85f1182f20f46a7784 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b971df4a482d14ae87d69399b8147ff1517c5a1f5f63bd85f1182f20f46a7784->enter($__internal_b971df4a482d14ae87d69399b8147ff1517c5a1f5f63bd85f1182f20f46a7784_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_62c5c2ca7eb6376ce044851dc8e547ae45178767749f4cd9a8ae1bd9d4e87c9a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_62c5c2ca7eb6376ce044851dc8e547ae45178767749f4cd9a8ae1bd9d4e87c9a->enter($__internal_62c5c2ca7eb6376ce044851dc8e547ae45178767749f4cd9a8ae1bd9d4e87c9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["file"]) ? $context["file"] : $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt((isset($context["filename"]) ? $context["filename"] : $this->getContext($context, "filename")), (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_62c5c2ca7eb6376ce044851dc8e547ae45178767749f4cd9a8ae1bd9d4e87c9a->leave($__internal_62c5c2ca7eb6376ce044851dc8e547ae45178767749f4cd9a8ae1bd9d4e87c9a_prof);

        
        $__internal_b971df4a482d14ae87d69399b8147ff1517c5a1f5f63bd85f1182f20f46a7784->leave($__internal_b971df4a482d14ae87d69399b8147ff1517c5a1f5f63bd85f1182f20f46a7784_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "WebProfilerBundle:Profiler:open.html.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/open.html.twig");
    }
}
