<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_b54d6022000fe417605866e69efacbf9481ee5629c0623f8c74a6772452cb520 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6871820f5ac1eec0e43d8c874809fed07a1ee318562d5a306ec11d8962397b88 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6871820f5ac1eec0e43d8c874809fed07a1ee318562d5a306ec11d8962397b88->enter($__internal_6871820f5ac1eec0e43d8c874809fed07a1ee318562d5a306ec11d8962397b88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_2e0717ad4dea7c9fc0b189ed9a037708e6cc8d5f1d089c490639cfc44bd65ff0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e0717ad4dea7c9fc0b189ed9a037708e6cc8d5f1d089c490639cfc44bd65ff0->enter($__internal_2e0717ad4dea7c9fc0b189ed9a037708e6cc8d5f1d089c490639cfc44bd65ff0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_6871820f5ac1eec0e43d8c874809fed07a1ee318562d5a306ec11d8962397b88->leave($__internal_6871820f5ac1eec0e43d8c874809fed07a1ee318562d5a306ec11d8962397b88_prof);

        
        $__internal_2e0717ad4dea7c9fc0b189ed9a037708e6cc8d5f1d089c490639cfc44bd65ff0->leave($__internal_2e0717ad4dea7c9fc0b189ed9a037708e6cc8d5f1d089c490639cfc44bd65ff0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_row.html.php");
    }
}
