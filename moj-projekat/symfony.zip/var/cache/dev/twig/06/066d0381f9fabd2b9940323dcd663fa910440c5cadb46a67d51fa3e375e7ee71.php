<?php

/* @Twig/Exception/error.txt.twig */
class __TwigTemplate_3f61f2c7516095264b1c2e8f0e64ae03b26d63e93f7af2da75bebebf00f4efd6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_292be0de2f12803694fc63284f6f6ca43b4443d871fa995011fe8db2cff2c16b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_292be0de2f12803694fc63284f6f6ca43b4443d871fa995011fe8db2cff2c16b->enter($__internal_292be0de2f12803694fc63284f6f6ca43b4443d871fa995011fe8db2cff2c16b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.txt.twig"));

        $__internal_b653d3535a3ce8cc13fa6c30c354b68dcd799a87e4aa8a8a501366b79cf99716 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b653d3535a3ce8cc13fa6c30c354b68dcd799a87e4aa8a8a501366b79cf99716->enter($__internal_b653d3535a3ce8cc13fa6c30c354b68dcd799a87e4aa8a8a501366b79cf99716_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code"));
        echo " ";
        echo (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text"));
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_292be0de2f12803694fc63284f6f6ca43b4443d871fa995011fe8db2cff2c16b->leave($__internal_292be0de2f12803694fc63284f6f6ca43b4443d871fa995011fe8db2cff2c16b_prof);

        
        $__internal_b653d3535a3ce8cc13fa6c30c354b68dcd799a87e4aa8a8a501366b79cf99716->leave($__internal_b653d3535a3ce8cc13fa6c30c354b68dcd799a87e4aa8a8a501366b79cf99716_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 4,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Oops! An Error Occurred
=======================

The server returned a \"{{ status_code }} {{ status_text }}\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
", "@Twig/Exception/error.txt.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.txt.twig");
    }
}
