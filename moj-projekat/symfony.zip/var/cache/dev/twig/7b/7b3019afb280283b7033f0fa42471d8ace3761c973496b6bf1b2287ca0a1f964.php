<?php

/* @Twig/Exception/error.json.twig */
class __TwigTemplate_d394dca680be5f3e6057b1d9b0f3cf7ef77ece120596e3c4ef815f94ee65c6ea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1c913e7be1f90c93a4a2eb050d58b10b67edad186e30b9e5535d3cb9f3c2144f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1c913e7be1f90c93a4a2eb050d58b10b67edad186e30b9e5535d3cb9f3c2144f->enter($__internal_1c913e7be1f90c93a4a2eb050d58b10b67edad186e30b9e5535d3cb9f3c2144f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        $__internal_598618b2ce860b9adbdc69a5ede7bb32caa828ca77ca69be85622f9a1679ae4b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_598618b2ce860b9adbdc69a5ede7bb32caa828ca77ca69be85622f9a1679ae4b->enter($__internal_598618b2ce860b9adbdc69a5ede7bb32caa828ca77ca69be85622f9a1679ae4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_1c913e7be1f90c93a4a2eb050d58b10b67edad186e30b9e5535d3cb9f3c2144f->leave($__internal_1c913e7be1f90c93a4a2eb050d58b10b67edad186e30b9e5535d3cb9f3c2144f_prof);

        
        $__internal_598618b2ce860b9adbdc69a5ede7bb32caa828ca77ca69be85622f9a1679ae4b->leave($__internal_598618b2ce860b9adbdc69a5ede7bb32caa828ca77ca69be85622f9a1679ae4b_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "@Twig/Exception/error.json.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.json.twig");
    }
}
