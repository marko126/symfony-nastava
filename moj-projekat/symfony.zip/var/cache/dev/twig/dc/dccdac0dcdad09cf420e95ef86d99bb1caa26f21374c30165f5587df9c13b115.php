<?php

/* :article:list.html.twig */
class __TwigTemplate_3259e40af156d4d96c898dcff93d038172e322bacaa2eea3201163dfaaafc6a6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", ":article:list.html.twig", 2);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5b088102368eeb12e479fb194c9183174c435b885cf76cc81e06f8e45be7f78c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5b088102368eeb12e479fb194c9183174c435b885cf76cc81e06f8e45be7f78c->enter($__internal_5b088102368eeb12e479fb194c9183174c435b885cf76cc81e06f8e45be7f78c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":article:list.html.twig"));

        $__internal_bc2b9d4a0d6aa56ffca67e8ebc5e7b2a55a578830c132f31edce192bdd0f9a44 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bc2b9d4a0d6aa56ffca67e8ebc5e7b2a55a578830c132f31edce192bdd0f9a44->enter($__internal_bc2b9d4a0d6aa56ffca67e8ebc5e7b2a55a578830c132f31edce192bdd0f9a44_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":article:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5b088102368eeb12e479fb194c9183174c435b885cf76cc81e06f8e45be7f78c->leave($__internal_5b088102368eeb12e479fb194c9183174c435b885cf76cc81e06f8e45be7f78c_prof);

        
        $__internal_bc2b9d4a0d6aa56ffca67e8ebc5e7b2a55a578830c132f31edce192bdd0f9a44->leave($__internal_bc2b9d4a0d6aa56ffca67e8ebc5e7b2a55a578830c132f31edce192bdd0f9a44_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_9312cc908dd3527cf1fd81b1f095e03a1632f72a90cb879a5fc26f756b06f26c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9312cc908dd3527cf1fd81b1f095e03a1632f72a90cb879a5fc26f756b06f26c->enter($__internal_9312cc908dd3527cf1fd81b1f095e03a1632f72a90cb879a5fc26f756b06f26c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_df2ca2ddee9b16e3de21df8f194a4c115abc2318f8ecd30550828c58cf3e7248 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df2ca2ddee9b16e3de21df8f194a4c115abc2318f8ecd30550828c58cf3e7248->enter($__internal_df2ca2ddee9b16e3de21df8f194a4c115abc2318f8ecd30550828c58cf3e7248_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "    
    <p>";
        // line 6
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, (isset($context["text"]) ? $context["text"] : $this->getContext($context, "text"))), "html", null, true);
        echo "</p>
    <br>
    
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Naziv</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["artikli"]) ? $context["artikli"] : $this->getContext($context, "artikli")));
        foreach ($context['_seq'] as $context["_key"] => $context["artikal"]) {
            // line 19
            echo "                <tr>
                    <td>";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["artikal"], "id", array(), "array"), "html", null, true);
            echo "</td>
                    <td>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["artikal"], "title", array(), "array"), "html", null, true);
            echo "</td>
                    <td><a href=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("article_show", array("name" => $this->getAttribute($context["artikal"], "title", array(), "array"))), "html", null, true);
            echo "\">Show</a></td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['artikal'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "        </tbody>
    </table>
    

";
        
        $__internal_df2ca2ddee9b16e3de21df8f194a4c115abc2318f8ecd30550828c58cf3e7248->leave($__internal_df2ca2ddee9b16e3de21df8f194a4c115abc2318f8ecd30550828c58cf3e7248_prof);

        
        $__internal_9312cc908dd3527cf1fd81b1f095e03a1632f72a90cb879a5fc26f756b06f26c->leave($__internal_9312cc908dd3527cf1fd81b1f095e03a1632f72a90cb879a5fc26f756b06f26c_prof);

    }

    public function getTemplateName()
    {
        return ":article:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  91 => 25,  82 => 22,  78 => 21,  74 => 20,  71 => 19,  67 => 18,  52 => 6,  49 => 5,  40 => 4,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# empty Twig template #}
{% extends \"base.html.twig\" %}

{% block body %}
    
    <p>{{ text|upper }}</p>
    <br>
    
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Naziv</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            {% for artikal in artikli %}
                <tr>
                    <td>{{ artikal['id'] }}</td>
                    <td>{{ artikal['title'] }}</td>
                    <td><a href=\"{{ path('article_show', { 'name' : artikal['title'] }) }}\">Show</a></td>
                </tr>
            {% endfor %}
        </tbody>
    </table>
    

{% endblock %}", ":article:list.html.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\app/Resources\\views/article/list.html.twig");
    }
}
