<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_952f78a2cbf44c74ea9f85014fbfc0f196e457eefcc8d7116161cc916888b57d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d85a2765179aeb15d2416820aa3f28f8d7b2caa531742598f7e99f3f4be0b558 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d85a2765179aeb15d2416820aa3f28f8d7b2caa531742598f7e99f3f4be0b558->enter($__internal_d85a2765179aeb15d2416820aa3f28f8d7b2caa531742598f7e99f3f4be0b558_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        $__internal_ce43a03a700a1063b9098068bb857c645c23b04a93392761853675447555c8ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce43a03a700a1063b9098068bb857c645c23b04a93392761853675447555c8ba->enter($__internal_ce43a03a700a1063b9098068bb857c645c23b04a93392761853675447555c8ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_d85a2765179aeb15d2416820aa3f28f8d7b2caa531742598f7e99f3f4be0b558->leave($__internal_d85a2765179aeb15d2416820aa3f28f8d7b2caa531742598f7e99f3f4be0b558_prof);

        
        $__internal_ce43a03a700a1063b9098068bb857c645c23b04a93392761853675447555c8ba->leave($__internal_ce43a03a700a1063b9098068bb857c645c23b04a93392761853675447555c8ba_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/checkbox_widget.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\checkbox_widget.html.php");
    }
}
