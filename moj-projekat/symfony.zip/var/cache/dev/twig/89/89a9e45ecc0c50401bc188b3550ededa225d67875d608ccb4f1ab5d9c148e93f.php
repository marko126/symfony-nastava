<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_9bb416c4f1cd767d67f9c596a4b07fdb85805052538cc3e0a13cb5411ccc6548 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_63197f99c695e5ab2efae78eb668adf7f8e997beac1413d278600fe0819954bd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_63197f99c695e5ab2efae78eb668adf7f8e997beac1413d278600fe0819954bd->enter($__internal_63197f99c695e5ab2efae78eb668adf7f8e997beac1413d278600fe0819954bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        $__internal_47eeb8d308ca815406bd1a30fcd49bcb9d43750121a7d8a51c4e82f4190dbbf0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_47eeb8d308ca815406bd1a30fcd49bcb9d43750121a7d8a51c4e82f4190dbbf0->enter($__internal_47eeb8d308ca815406bd1a30fcd49bcb9d43750121a7d8a51c4e82f4190dbbf0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.js.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_63197f99c695e5ab2efae78eb668adf7f8e997beac1413d278600fe0819954bd->leave($__internal_63197f99c695e5ab2efae78eb668adf7f8e997beac1413d278600fe0819954bd_prof);

        
        $__internal_47eeb8d308ca815406bd1a30fcd49bcb9d43750121a7d8a51c4e82f4190dbbf0->leave($__internal_47eeb8d308ca815406bd1a30fcd49bcb9d43750121a7d8a51c4e82f4190dbbf0_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}
*/
", "TwigBundle:Exception:exception.js.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.js.twig");
    }
}
