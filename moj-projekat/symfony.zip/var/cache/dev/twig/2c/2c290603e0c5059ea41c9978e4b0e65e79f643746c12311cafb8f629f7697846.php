<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_4148c5a61d846aec4b9f45eed941f8d07a29ebdd6f153c67804e3844d0dd5bea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_66bcc8041c7a2934a26c5a22643ce61e4f74b72d6dc951e3a4e2824186b49a38 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_66bcc8041c7a2934a26c5a22643ce61e4f74b72d6dc951e3a4e2824186b49a38->enter($__internal_66bcc8041c7a2934a26c5a22643ce61e4f74b72d6dc951e3a4e2824186b49a38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_2e1158ee6c000ef9765a36e84b1ab909eb767d42089ca89c5e8d7efccfdad474 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e1158ee6c000ef9765a36e84b1ab909eb767d42089ca89c5e8d7efccfdad474->enter($__internal_2e1158ee6c000ef9765a36e84b1ab909eb767d42089ca89c5e8d7efccfdad474_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_66bcc8041c7a2934a26c5a22643ce61e4f74b72d6dc951e3a4e2824186b49a38->leave($__internal_66bcc8041c7a2934a26c5a22643ce61e4f74b72d6dc951e3a4e2824186b49a38_prof);

        
        $__internal_2e1158ee6c000ef9765a36e84b1ab909eb767d42089ca89c5e8d7efccfdad474->leave($__internal_2e1158ee6c000ef9765a36e84b1ab909eb767d42089ca89c5e8d7efccfdad474_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_label.html.php");
    }
}
