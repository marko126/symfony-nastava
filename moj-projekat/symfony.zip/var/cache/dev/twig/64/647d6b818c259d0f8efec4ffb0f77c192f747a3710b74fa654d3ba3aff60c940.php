<?php

/* article/list.html.twig */
class __TwigTemplate_54b294a4637effdd10996ede9c6c82a4be4cceb0c19b5e6fa1990295e32e40a5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "article/list.html.twig", 2);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fda612d9de29d76faf2e13588bd22595e8f00cc34eda003ce455255352c03eae = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fda612d9de29d76faf2e13588bd22595e8f00cc34eda003ce455255352c03eae->enter($__internal_fda612d9de29d76faf2e13588bd22595e8f00cc34eda003ce455255352c03eae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "article/list.html.twig"));

        $__internal_1948afd9601784cc3a78a9e4ca9ee2747c7aec37f1a1a31d0927acd55d854bd5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1948afd9601784cc3a78a9e4ca9ee2747c7aec37f1a1a31d0927acd55d854bd5->enter($__internal_1948afd9601784cc3a78a9e4ca9ee2747c7aec37f1a1a31d0927acd55d854bd5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "article/list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fda612d9de29d76faf2e13588bd22595e8f00cc34eda003ce455255352c03eae->leave($__internal_fda612d9de29d76faf2e13588bd22595e8f00cc34eda003ce455255352c03eae_prof);

        
        $__internal_1948afd9601784cc3a78a9e4ca9ee2747c7aec37f1a1a31d0927acd55d854bd5->leave($__internal_1948afd9601784cc3a78a9e4ca9ee2747c7aec37f1a1a31d0927acd55d854bd5_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_2b761cb186ce0333e6bd15cb862fabe0d45bd390aa72abf00ae6138dcc16d0ad = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2b761cb186ce0333e6bd15cb862fabe0d45bd390aa72abf00ae6138dcc16d0ad->enter($__internal_2b761cb186ce0333e6bd15cb862fabe0d45bd390aa72abf00ae6138dcc16d0ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_6789a05c37b29a0abe929523c025eba8c9b4e3b248c0985f785297de2a153815 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6789a05c37b29a0abe929523c025eba8c9b4e3b248c0985f785297de2a153815->enter($__internal_6789a05c37b29a0abe929523c025eba8c9b4e3b248c0985f785297de2a153815_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "    
    <p>";
        // line 6
        echo twig_escape_filter($this->env, twig_upper_filter($this->env, (isset($context["text"]) ? $context["text"] : $this->getContext($context, "text"))), "html", null, true);
        echo "</p>
    <br>
    
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Naziv</th>
                <th>Kategorija</th>
                <th>Cena</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["artikli"]) ? $context["artikli"] : $this->getContext($context, "artikli")));
        foreach ($context['_seq'] as $context["_key"] => $context["artikal"]) {
            // line 21
            echo "                <tr>
                    <td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["artikal"], "id", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["artikal"], "name", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["artikal"], "category", array()), "html", null, true);
            echo "</td>
                    <td>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["artikal"], "price", array()), "html", null, true);
            echo "</td>
                    <td><a href=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("article_show", array("id" => $this->getAttribute($context["artikal"], "id", array()), "name" => $this->getAttribute($context["artikal"], "name", array()))), "html", null, true);
            echo "\">Show</a></td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['artikal'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 29
        echo "        </tbody>
    </table>
    

";
        
        $__internal_6789a05c37b29a0abe929523c025eba8c9b4e3b248c0985f785297de2a153815->leave($__internal_6789a05c37b29a0abe929523c025eba8c9b4e3b248c0985f785297de2a153815_prof);

        
        $__internal_2b761cb186ce0333e6bd15cb862fabe0d45bd390aa72abf00ae6138dcc16d0ad->leave($__internal_2b761cb186ce0333e6bd15cb862fabe0d45bd390aa72abf00ae6138dcc16d0ad_prof);

    }

    public function getTemplateName()
    {
        return "article/list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  101 => 29,  92 => 26,  88 => 25,  84 => 24,  80 => 23,  76 => 22,  73 => 21,  69 => 20,  52 => 6,  49 => 5,  40 => 4,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# empty Twig template #}
{% extends \"base.html.twig\" %}

{% block body %}
    
    <p>{{ text|upper }}</p>
    <br>
    
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Naziv</th>
                <th>Kategorija</th>
                <th>Cena</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            {% for artikal in artikli %}
                <tr>
                    <td>{{ artikal.id }}</td>
                    <td>{{ artikal.name }}</td>
                    <td>{{ artikal.category }}</td>
                    <td>{{ artikal.price }}</td>
                    <td><a href=\"{{ path('article_show', { 'id' : artikal.id, 'name' : artikal.name }) }}\">Show</a></td>
                </tr>
            {% endfor %}
        </tbody>
    </table>
    

{% endblock %}", "article/list.html.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\app\\Resources\\views\\article\\list.html.twig");
    }
}
