<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_a022ae214cf77191a29f8ad1b0de82dea9640f2d497ffe3c13478237ea59eb76 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f54fbd8a1639cb585098118eb51c5c013967b0525b252b55f76b33e53d543ccf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f54fbd8a1639cb585098118eb51c5c013967b0525b252b55f76b33e53d543ccf->enter($__internal_f54fbd8a1639cb585098118eb51c5c013967b0525b252b55f76b33e53d543ccf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        $__internal_2c588cf4c149461259443664b65682ccc834b64a93563474cf43a1817b998127 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2c588cf4c149461259443664b65682ccc834b64a93563474cf43a1817b998127->enter($__internal_2c588cf4c149461259443664b65682ccc834b64a93563474cf43a1817b998127_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_f54fbd8a1639cb585098118eb51c5c013967b0525b252b55f76b33e53d543ccf->leave($__internal_f54fbd8a1639cb585098118eb51c5c013967b0525b252b55f76b33e53d543ccf_prof);

        
        $__internal_2c588cf4c149461259443664b65682ccc834b64a93563474cf43a1817b998127->leave($__internal_2c588cf4c149461259443664b65682ccc834b64a93563474cf43a1817b998127_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\collection_widget.html.php");
    }
}
