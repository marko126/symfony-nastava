<?php

/* @WebProfiler/Profiler/open.html.twig */
class __TwigTemplate_e113816bc71690783034fca4f2fc0a085b2da1e983711864b94fcfbfbafbd8b7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "@WebProfiler/Profiler/open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_58ec04340ca973b66a31651626a995efa6f4c1e49eef7cb5a361ba79a2389593 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_58ec04340ca973b66a31651626a995efa6f4c1e49eef7cb5a361ba79a2389593->enter($__internal_58ec04340ca973b66a31651626a995efa6f4c1e49eef7cb5a361ba79a2389593_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $__internal_dad8b92a3865dc4a31338a9f0947de3fc16d52713622767daca6255b5bc15d94 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dad8b92a3865dc4a31338a9f0947de3fc16d52713622767daca6255b5bc15d94->enter($__internal_dad8b92a3865dc4a31338a9f0947de3fc16d52713622767daca6255b5bc15d94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_58ec04340ca973b66a31651626a995efa6f4c1e49eef7cb5a361ba79a2389593->leave($__internal_58ec04340ca973b66a31651626a995efa6f4c1e49eef7cb5a361ba79a2389593_prof);

        
        $__internal_dad8b92a3865dc4a31338a9f0947de3fc16d52713622767daca6255b5bc15d94->leave($__internal_dad8b92a3865dc4a31338a9f0947de3fc16d52713622767daca6255b5bc15d94_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_8fe25ddb0d50e5adb492d58a1f93455c03ae76b58ff2524a81cbb290fa475b6c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8fe25ddb0d50e5adb492d58a1f93455c03ae76b58ff2524a81cbb290fa475b6c->enter($__internal_8fe25ddb0d50e5adb492d58a1f93455c03ae76b58ff2524a81cbb290fa475b6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_144c96bfa9bc7caa56f1d967474ec0df03d4bb2798cab40a3739a79fde2bb019 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_144c96bfa9bc7caa56f1d967474ec0df03d4bb2798cab40a3739a79fde2bb019->enter($__internal_144c96bfa9bc7caa56f1d967474ec0df03d4bb2798cab40a3739a79fde2bb019_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_144c96bfa9bc7caa56f1d967474ec0df03d4bb2798cab40a3739a79fde2bb019->leave($__internal_144c96bfa9bc7caa56f1d967474ec0df03d4bb2798cab40a3739a79fde2bb019_prof);

        
        $__internal_8fe25ddb0d50e5adb492d58a1f93455c03ae76b58ff2524a81cbb290fa475b6c->leave($__internal_8fe25ddb0d50e5adb492d58a1f93455c03ae76b58ff2524a81cbb290fa475b6c_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_5c79f839f99ad54a6e5cd373845b20357e374b123e5f0fdd1537305086e6c22f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5c79f839f99ad54a6e5cd373845b20357e374b123e5f0fdd1537305086e6c22f->enter($__internal_5c79f839f99ad54a6e5cd373845b20357e374b123e5f0fdd1537305086e6c22f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_da21af08fd798a51e66ebf48d683e36835f8d24b5ccfa0d35f0b7d452715aec6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_da21af08fd798a51e66ebf48d683e36835f8d24b5ccfa0d35f0b7d452715aec6->enter($__internal_da21af08fd798a51e66ebf48d683e36835f8d24b5ccfa0d35f0b7d452715aec6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["file"]) ? $context["file"] : $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt((isset($context["filename"]) ? $context["filename"] : $this->getContext($context, "filename")), (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_da21af08fd798a51e66ebf48d683e36835f8d24b5ccfa0d35f0b7d452715aec6->leave($__internal_da21af08fd798a51e66ebf48d683e36835f8d24b5ccfa0d35f0b7d452715aec6_prof);

        
        $__internal_5c79f839f99ad54a6e5cd373845b20357e374b123e5f0fdd1537305086e6c22f->leave($__internal_5c79f839f99ad54a6e5cd373845b20357e374b123e5f0fdd1537305086e6c22f_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "@WebProfiler/Profiler/open.html.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\open.html.twig");
    }
}
