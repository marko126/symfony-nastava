<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_9790f5e4e6918919e288ddb82a7b508f8fca4b07961d28364b5dc27057ffff27 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0a49bfa0c5f18ce3d29a126d42688ed2e53d320743fc75110c73f00a867dcdf4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0a49bfa0c5f18ce3d29a126d42688ed2e53d320743fc75110c73f00a867dcdf4->enter($__internal_0a49bfa0c5f18ce3d29a126d42688ed2e53d320743fc75110c73f00a867dcdf4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        $__internal_d36a26d3cb35d61cce7ff83321fc3c6195b965af0f04ad0b03851e195e2bcf5e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d36a26d3cb35d61cce7ff83321fc3c6195b965af0f04ad0b03851e195e2bcf5e->enter($__internal_d36a26d3cb35d61cce7ff83321fc3c6195b965af0f04ad0b03851e195e2bcf5e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_0a49bfa0c5f18ce3d29a126d42688ed2e53d320743fc75110c73f00a867dcdf4->leave($__internal_0a49bfa0c5f18ce3d29a126d42688ed2e53d320743fc75110c73f00a867dcdf4_prof);

        
        $__internal_d36a26d3cb35d61cce7ff83321fc3c6195b965af0f04ad0b03851e195e2bcf5e->leave($__internal_d36a26d3cb35d61cce7ff83321fc3c6195b965af0f04ad0b03851e195e2bcf5e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
", "@Framework/Form/form_widget_simple.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget_simple.html.php");
    }
}
