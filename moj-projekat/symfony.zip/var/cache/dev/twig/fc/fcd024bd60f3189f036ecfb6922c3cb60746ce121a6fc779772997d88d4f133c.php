<?php

/* @Twig/Exception/exception.css.twig */
class __TwigTemplate_d9486e99bdaa5961eeaf8a200e21a876d1f587addc753dacd4c3a655ad078743 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ae132f53c48de0da7df482818b2c455a8ab372643595175684cedce6cae41249 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ae132f53c48de0da7df482818b2c455a8ab372643595175684cedce6cae41249->enter($__internal_ae132f53c48de0da7df482818b2c455a8ab372643595175684cedce6cae41249_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        $__internal_eb6eba2ade3e6f6ea47def992e5cfcd98f2638894acefd71fdb0cc1d72d970d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb6eba2ade3e6f6ea47def992e5cfcd98f2638894acefd71fdb0cc1d72d970d2->enter($__internal_eb6eba2ade3e6f6ea47def992e5cfcd98f2638894acefd71fdb0cc1d72d970d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "@Twig/Exception/exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_ae132f53c48de0da7df482818b2c455a8ab372643595175684cedce6cae41249->leave($__internal_ae132f53c48de0da7df482818b2c455a8ab372643595175684cedce6cae41249_prof);

        
        $__internal_eb6eba2ade3e6f6ea47def992e5cfcd98f2638894acefd71fdb0cc1d72d970d2->leave($__internal_eb6eba2ade3e6f6ea47def992e5cfcd98f2638894acefd71fdb0cc1d72d970d2_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}
*/
", "@Twig/Exception/exception.css.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.css.twig");
    }
}
