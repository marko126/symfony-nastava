<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_86d991ac2a52fd0c0ffdf48744e9f3d1019c31dc7d44c915dab2a5b0a1fa03cc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_156b30636d143892f19d56b43b6582a647b8dd673e6422c8f2eb7425537389f7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_156b30636d143892f19d56b43b6582a647b8dd673e6422c8f2eb7425537389f7->enter($__internal_156b30636d143892f19d56b43b6582a647b8dd673e6422c8f2eb7425537389f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        $__internal_f727c9757f211fa2ceb25c7ade6518ec99ece2bb629668179ba71fd5099edeb0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f727c9757f211fa2ceb25c7ade6518ec99ece2bb629668179ba71fd5099edeb0->enter($__internal_f727c9757f211fa2ceb25c7ade6518ec99ece2bb629668179ba71fd5099edeb0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_156b30636d143892f19d56b43b6582a647b8dd673e6422c8f2eb7425537389f7->leave($__internal_156b30636d143892f19d56b43b6582a647b8dd673e6422c8f2eb7425537389f7_prof);

        
        $__internal_f727c9757f211fa2ceb25c7ade6518ec99ece2bb629668179ba71fd5099edeb0->leave($__internal_f727c9757f211fa2ceb25c7ade6518ec99ece2bb629668179ba71fd5099edeb0_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
", "TwigBundle:Exception:exception.rdf.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.rdf.twig");
    }
}
