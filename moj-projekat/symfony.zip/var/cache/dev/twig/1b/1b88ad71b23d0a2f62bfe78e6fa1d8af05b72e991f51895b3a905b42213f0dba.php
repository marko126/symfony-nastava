<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_e37f1b761b417b3da6fffbe8d6846b204a416c7e5e317d0bb8adb125a958b4c3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ce9b4c084524a15f0a94d8dc92377c54a231cbdc691a896710747cb7fe6af8a8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ce9b4c084524a15f0a94d8dc92377c54a231cbdc691a896710747cb7fe6af8a8->enter($__internal_ce9b4c084524a15f0a94d8dc92377c54a231cbdc691a896710747cb7fe6af8a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_c2fa0ea9c832699c56bac1a12e9325272179c7168a430a501238f34007a3dbee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c2fa0ea9c832699c56bac1a12e9325272179c7168a430a501238f34007a3dbee->enter($__internal_c2fa0ea9c832699c56bac1a12e9325272179c7168a430a501238f34007a3dbee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_ce9b4c084524a15f0a94d8dc92377c54a231cbdc691a896710747cb7fe6af8a8->leave($__internal_ce9b4c084524a15f0a94d8dc92377c54a231cbdc691a896710747cb7fe6af8a8_prof);

        
        $__internal_c2fa0ea9c832699c56bac1a12e9325272179c7168a430a501238f34007a3dbee->leave($__internal_c2fa0ea9c832699c56bac1a12e9325272179c7168a430a501238f34007a3dbee_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
", "TwigBundle:Exception:exception.atom.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
