<?php

/* :article:show.html.twig */
class __TwigTemplate_5c111f5eca9d2096fece71cf688147c94e48069a2a4578168857e865c7b6e159 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", ":article:show.html.twig", 2);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dab80b9ba28959e15b5199a5659901e775cf835d53781e59b374e1e624659986 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dab80b9ba28959e15b5199a5659901e775cf835d53781e59b374e1e624659986->enter($__internal_dab80b9ba28959e15b5199a5659901e775cf835d53781e59b374e1e624659986_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":article:show.html.twig"));

        $__internal_6d51919964f12c4bf727e4be6491d89c5d2f678bd0e7d43830e7c67a9b973b36 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d51919964f12c4bf727e4be6491d89c5d2f678bd0e7d43830e7c67a9b973b36->enter($__internal_6d51919964f12c4bf727e4be6491d89c5d2f678bd0e7d43830e7c67a9b973b36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":article:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dab80b9ba28959e15b5199a5659901e775cf835d53781e59b374e1e624659986->leave($__internal_dab80b9ba28959e15b5199a5659901e775cf835d53781e59b374e1e624659986_prof);

        
        $__internal_6d51919964f12c4bf727e4be6491d89c5d2f678bd0e7d43830e7c67a9b973b36->leave($__internal_6d51919964f12c4bf727e4be6491d89c5d2f678bd0e7d43830e7c67a9b973b36_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_2b177d14fec240dd0e7ee7af625df79cde7bb54f138fbe5020a94fd3d2d7ac5a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2b177d14fec240dd0e7ee7af625df79cde7bb54f138fbe5020a94fd3d2d7ac5a->enter($__internal_2b177d14fec240dd0e7ee7af625df79cde7bb54f138fbe5020a94fd3d2d7ac5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_0dec9f8138514989cfbdbb8647683421773e9a1faaa91a36c674ec835c33dbc3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0dec9f8138514989cfbdbb8647683421773e9a1faaa91a36c674ec835c33dbc3->enter($__internal_0dec9f8138514989cfbdbb8647683421773e9a1faaa91a36c674ec835c33dbc3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "    
    <h2>Proizvod #";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["artikal"]) ? $context["artikal"] : $this->getContext($context, "artikal")), "id", array(), "array"), "html", null, true);
        echo "</h2>
    <h3>Author: ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["artikal"]) ? $context["artikal"] : $this->getContext($context, "artikal")), "author", array(), "array"), "html", null, true);
        echo "</h3>
    <p>Naziv: ";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["artikal"]) ? $context["artikal"] : $this->getContext($context, "artikal")), "title", array(), "array"), "html", null, true);
        echo "</p>
    
";
        
        $__internal_0dec9f8138514989cfbdbb8647683421773e9a1faaa91a36c674ec835c33dbc3->leave($__internal_0dec9f8138514989cfbdbb8647683421773e9a1faaa91a36c674ec835c33dbc3_prof);

        
        $__internal_2b177d14fec240dd0e7ee7af625df79cde7bb54f138fbe5020a94fd3d2d7ac5a->leave($__internal_2b177d14fec240dd0e7ee7af625df79cde7bb54f138fbe5020a94fd3d2d7ac5a_prof);

    }

    public function getTemplateName()
    {
        return ":article:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 8,  56 => 7,  52 => 6,  49 => 5,  40 => 4,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# empty Twig template #}
{% extends \"base.html.twig\" %}

{% block body %}
    
    <h2>Proizvod #{{ artikal['id'] }}</h2>
    <h3>Author: {{ artikal['author'] }}</h3>
    <p>Naziv: {{ artikal['title'] }}</p>
    
{% endblock %}
", ":article:show.html.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\app/Resources\\views/article/show.html.twig");
    }
}
