<?php

/* article/show.html.twig */
class __TwigTemplate_7736593db21fa60f9a7a0695f2a3c63b855e0fe76bd1b24a40e1e0ac69da8a35 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "article/show.html.twig", 2);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ebafc238561288e1ae607541cbca7b0a3200b5e0d29b1965284537dc3995a491 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ebafc238561288e1ae607541cbca7b0a3200b5e0d29b1965284537dc3995a491->enter($__internal_ebafc238561288e1ae607541cbca7b0a3200b5e0d29b1965284537dc3995a491_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "article/show.html.twig"));

        $__internal_03dca77d6fbf856a7b47b2cb6d5e45cbac69e894fa45ffc9f0ac19291eb49512 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_03dca77d6fbf856a7b47b2cb6d5e45cbac69e894fa45ffc9f0ac19291eb49512->enter($__internal_03dca77d6fbf856a7b47b2cb6d5e45cbac69e894fa45ffc9f0ac19291eb49512_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "article/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ebafc238561288e1ae607541cbca7b0a3200b5e0d29b1965284537dc3995a491->leave($__internal_ebafc238561288e1ae607541cbca7b0a3200b5e0d29b1965284537dc3995a491_prof);

        
        $__internal_03dca77d6fbf856a7b47b2cb6d5e45cbac69e894fa45ffc9f0ac19291eb49512->leave($__internal_03dca77d6fbf856a7b47b2cb6d5e45cbac69e894fa45ffc9f0ac19291eb49512_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_32d0a8c6e0cc2f54fffe8009c8e6e5dbaaf5af97d425eeed655202fbf94b481f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_32d0a8c6e0cc2f54fffe8009c8e6e5dbaaf5af97d425eeed655202fbf94b481f->enter($__internal_32d0a8c6e0cc2f54fffe8009c8e6e5dbaaf5af97d425eeed655202fbf94b481f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b9fafb5368e3026598c5d286ad7c8405ed02c79e692f01bd5e49ed5a9d1057fd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b9fafb5368e3026598c5d286ad7c8405ed02c79e692f01bd5e49ed5a9d1057fd->enter($__internal_b9fafb5368e3026598c5d286ad7c8405ed02c79e692f01bd5e49ed5a9d1057fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "    
    <h2>";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["artikal"]) ? $context["artikal"] : $this->getContext($context, "artikal")), "name", array()), "html", null, true);
        echo "</h2>
    <p>Kategorija: ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["artikal"]) ? $context["artikal"] : $this->getContext($context, "artikal")), "category", array()), "html", null, true);
        echo "</p>
    <p>Cena: ";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["artikal"]) ? $context["artikal"] : $this->getContext($context, "artikal")), "price", array()), "html", null, true);
        echo "</p>
    
";
        
        $__internal_b9fafb5368e3026598c5d286ad7c8405ed02c79e692f01bd5e49ed5a9d1057fd->leave($__internal_b9fafb5368e3026598c5d286ad7c8405ed02c79e692f01bd5e49ed5a9d1057fd_prof);

        
        $__internal_32d0a8c6e0cc2f54fffe8009c8e6e5dbaaf5af97d425eeed655202fbf94b481f->leave($__internal_32d0a8c6e0cc2f54fffe8009c8e6e5dbaaf5af97d425eeed655202fbf94b481f_prof);

    }

    public function getTemplateName()
    {
        return "article/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 8,  56 => 7,  52 => 6,  49 => 5,  40 => 4,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# empty Twig template #}
{% extends \"base.html.twig\" %}

{% block body %}
    
    <h2>{{ artikal.name }}</h2>
    <p>Kategorija: {{ artikal.category }}</p>
    <p>Cena: {{ artikal.price }}</p>
    
{% endblock %}", "article/show.html.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\app\\Resources\\views\\article\\show.html.twig");
    }
}
