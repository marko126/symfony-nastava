<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_089ac7fceee8e87fcecf0ddd6e4a3d095e631163639418f2c9accd2dfe676036 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_20f80874b32c170680cc124cf84ec55a9b39b76fb1c1c3e7fcf627d34158b24c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_20f80874b32c170680cc124cf84ec55a9b39b76fb1c1c3e7fcf627d34158b24c->enter($__internal_20f80874b32c170680cc124cf84ec55a9b39b76fb1c1c3e7fcf627d34158b24c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        $__internal_acc99e256185c551571332cb3b354a5b016f47bf3f66e867c800ae3864884442 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_acc99e256185c551571332cb3b354a5b016f47bf3f66e867c800ae3864884442->enter($__internal_acc99e256185c551571332cb3b354a5b016f47bf3f66e867c800ae3864884442_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_20f80874b32c170680cc124cf84ec55a9b39b76fb1c1c3e7fcf627d34158b24c->leave($__internal_20f80874b32c170680cc124cf84ec55a9b39b76fb1c1c3e7fcf627d34158b24c_prof);

        
        $__internal_acc99e256185c551571332cb3b354a5b016f47bf3f66e867c800ae3864884442->leave($__internal_acc99e256185c551571332cb3b354a5b016f47bf3f66e867c800ae3864884442_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
", "@Framework/Form/form_errors.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_errors.html.php");
    }
}
