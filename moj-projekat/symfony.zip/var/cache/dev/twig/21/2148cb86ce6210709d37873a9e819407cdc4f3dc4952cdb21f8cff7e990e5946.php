<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_df13d4023853a5e5e0e28ba64b6570012ab7b029050ca0e9ed6631d16edc7d2b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1dcbfc8f24b3d8f389fafeea707bcd8b44056611897c121986b2b392fb19de80 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1dcbfc8f24b3d8f389fafeea707bcd8b44056611897c121986b2b392fb19de80->enter($__internal_1dcbfc8f24b3d8f389fafeea707bcd8b44056611897c121986b2b392fb19de80_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        $__internal_eb17fe604fb67c6695eb3809e5e76f53491a346c563a3ea5d3cfe4e12c94dc99 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb17fe604fb67c6695eb3809e5e76f53491a346c563a3ea5d3cfe4e12c94dc99->enter($__internal_eb17fe604fb67c6695eb3809e5e76f53491a346c563a3ea5d3cfe4e12c94dc99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_1dcbfc8f24b3d8f389fafeea707bcd8b44056611897c121986b2b392fb19de80->leave($__internal_1dcbfc8f24b3d8f389fafeea707bcd8b44056611897c121986b2b392fb19de80_prof);

        
        $__internal_eb17fe604fb67c6695eb3809e5e76f53491a346c563a3ea5d3cfe4e12c94dc99->leave($__internal_eb17fe604fb67c6695eb3809e5e76f53491a346c563a3ea5d3cfe4e12c94dc99_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "TwigBundle:Exception:error.json.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.json.twig");
    }
}
