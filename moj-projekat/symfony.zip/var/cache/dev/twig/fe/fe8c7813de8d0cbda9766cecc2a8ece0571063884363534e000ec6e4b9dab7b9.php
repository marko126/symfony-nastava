<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_e2fcd6c1a6881ff343558d2f7d43a5f8ca5ecb4d0b869c59bc3e852d5b2234fe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cb6f590daaee5626fb1568b30fcb051c252ccb4c7277ce241c17e394360bd904 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb6f590daaee5626fb1568b30fcb051c252ccb4c7277ce241c17e394360bd904->enter($__internal_cb6f590daaee5626fb1568b30fcb051c252ccb4c7277ce241c17e394360bd904_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        $__internal_ac5b90e76951f62ddd5cd32d13cdba72428d6856386563a312e6b6ff27ad97e9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac5b90e76951f62ddd5cd32d13cdba72428d6856386563a312e6b6ff27ad97e9->enter($__internal_ac5b90e76951f62ddd5cd32d13cdba72428d6856386563a312e6b6ff27ad97e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_cb6f590daaee5626fb1568b30fcb051c252ccb4c7277ce241c17e394360bd904->leave($__internal_cb6f590daaee5626fb1568b30fcb051c252ccb4c7277ce241c17e394360bd904_prof);

        
        $__internal_ac5b90e76951f62ddd5cd32d13cdba72428d6856386563a312e6b6ff27ad97e9->leave($__internal_ac5b90e76951f62ddd5cd32d13cdba72428d6856386563a312e6b6ff27ad97e9_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_9c554cb59d609b8da866b44f981f1e434fb4180cb6367cf699f927194fec526d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9c554cb59d609b8da866b44f981f1e434fb4180cb6367cf699f927194fec526d->enter($__internal_9c554cb59d609b8da866b44f981f1e434fb4180cb6367cf699f927194fec526d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_e5e573e75037e95c67ad4bfe63cd8f6470d271a11d36d63d4b56ab27302a65fa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e5e573e75037e95c67ad4bfe63cd8f6470d271a11d36d63d4b56ab27302a65fa->enter($__internal_e5e573e75037e95c67ad4bfe63cd8f6470d271a11d36d63d4b56ab27302a65fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_e5e573e75037e95c67ad4bfe63cd8f6470d271a11d36d63d4b56ab27302a65fa->leave($__internal_e5e573e75037e95c67ad4bfe63cd8f6470d271a11d36d63d4b56ab27302a65fa_prof);

        
        $__internal_9c554cb59d609b8da866b44f981f1e434fb4180cb6367cf699f927194fec526d->leave($__internal_9c554cb59d609b8da866b44f981f1e434fb4180cb6367cf699f927194fec526d_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
