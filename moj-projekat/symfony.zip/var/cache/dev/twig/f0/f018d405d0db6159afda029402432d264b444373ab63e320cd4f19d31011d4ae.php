<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_8860c6941967d9228f27740cacf663b49b7413cfeda12bc780cb47a1153cfd55 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_73f016b066fbc2cd0693c9e79899fed7f6b43269eb913f8f37d567d6887c3698 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_73f016b066fbc2cd0693c9e79899fed7f6b43269eb913f8f37d567d6887c3698->enter($__internal_73f016b066fbc2cd0693c9e79899fed7f6b43269eb913f8f37d567d6887c3698_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        $__internal_dc337cb383f9795eebac8d14eda836ae02116a70aa6c085310c46c2453cc4e28 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dc337cb383f9795eebac8d14eda836ae02116a70aa6c085310c46c2453cc4e28->enter($__internal_dc337cb383f9795eebac8d14eda836ae02116a70aa6c085310c46c2453cc4e28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_73f016b066fbc2cd0693c9e79899fed7f6b43269eb913f8f37d567d6887c3698->leave($__internal_73f016b066fbc2cd0693c9e79899fed7f6b43269eb913f8f37d567d6887c3698_prof);

        
        $__internal_dc337cb383f9795eebac8d14eda836ae02116a70aa6c085310c46c2453cc4e28->leave($__internal_dc337cb383f9795eebac8d14eda836ae02116a70aa6c085310c46c2453cc4e28_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
", "@Framework/Form/form_rest.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_rest.html.php");
    }
}
