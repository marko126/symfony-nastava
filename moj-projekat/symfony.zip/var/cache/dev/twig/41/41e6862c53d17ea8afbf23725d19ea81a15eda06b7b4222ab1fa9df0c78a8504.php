<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_c28df4e19a2e60fa61972e3dd20caff16f8c8270ba2062082c56edcaa548e600 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_65c777873665bd5cd841a06f36d46b7b00863377a69bb7a61cc9d9c6417d29ef = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_65c777873665bd5cd841a06f36d46b7b00863377a69bb7a61cc9d9c6417d29ef->enter($__internal_65c777873665bd5cd841a06f36d46b7b00863377a69bb7a61cc9d9c6417d29ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        $__internal_3c59d7c10554ed6e4fc18508d0dd55a8c5db307fb328eb1b7ed98fbc39445c46 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3c59d7c10554ed6e4fc18508d0dd55a8c5db307fb328eb1b7ed98fbc39445c46->enter($__internal_3c59d7c10554ed6e4fc18508d0dd55a8c5db307fb328eb1b7ed98fbc39445c46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.atom.twig", 1)->display($context);
        
        $__internal_65c777873665bd5cd841a06f36d46b7b00863377a69bb7a61cc9d9c6417d29ef->leave($__internal_65c777873665bd5cd841a06f36d46b7b00863377a69bb7a61cc9d9c6417d29ef_prof);

        
        $__internal_3c59d7c10554ed6e4fc18508d0dd55a8c5db307fb328eb1b7ed98fbc39445c46->leave($__internal_3c59d7c10554ed6e4fc18508d0dd55a8c5db307fb328eb1b7ed98fbc39445c46_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "@Twig/Exception/error.atom.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.atom.twig");
    }
}
