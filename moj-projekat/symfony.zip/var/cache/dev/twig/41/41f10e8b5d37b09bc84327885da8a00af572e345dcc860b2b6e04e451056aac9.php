<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_fb3b13c01d4f58f01bbe066a221a88184b3009d317cf2b8fb902f1a3b77a1969 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_12d6be683a118b155a045c3ea09e091f9967d328c7d127de92ffc2d15a2ce88f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_12d6be683a118b155a045c3ea09e091f9967d328c7d127de92ffc2d15a2ce88f->enter($__internal_12d6be683a118b155a045c3ea09e091f9967d328c7d127de92ffc2d15a2ce88f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_1a01e8086a0cf25cdd54680a19fd974653577da5c7472d8408fe9c7711af01c9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1a01e8086a0cf25cdd54680a19fd974653577da5c7472d8408fe9c7711af01c9->enter($__internal_1a01e8086a0cf25cdd54680a19fd974653577da5c7472d8408fe9c7711af01c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_12d6be683a118b155a045c3ea09e091f9967d328c7d127de92ffc2d15a2ce88f->leave($__internal_12d6be683a118b155a045c3ea09e091f9967d328c7d127de92ffc2d15a2ce88f_prof);

        
        $__internal_1a01e8086a0cf25cdd54680a19fd974653577da5c7472d8408fe9c7711af01c9->leave($__internal_1a01e8086a0cf25cdd54680a19fd974653577da5c7472d8408fe9c7711af01c9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\button_row.html.php");
    }
}
