<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_cd0d933db5020e7c4fc4e7c3e160c6ef26fdfb910695c4aaff50304c68da7681 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a8ad87198d770939eab2d89d501683d117e06016b3692f70eafac9e70d1fc3dd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a8ad87198d770939eab2d89d501683d117e06016b3692f70eafac9e70d1fc3dd->enter($__internal_a8ad87198d770939eab2d89d501683d117e06016b3692f70eafac9e70d1fc3dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_9817ee4d0693b2a129a6d291c1bc7ae97929c5ab54af3da31185672275167201 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9817ee4d0693b2a129a6d291c1bc7ae97929c5ab54af3da31185672275167201->enter($__internal_9817ee4d0693b2a129a6d291c1bc7ae97929c5ab54af3da31185672275167201_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_a8ad87198d770939eab2d89d501683d117e06016b3692f70eafac9e70d1fc3dd->leave($__internal_a8ad87198d770939eab2d89d501683d117e06016b3692f70eafac9e70d1fc3dd_prof);

        
        $__internal_9817ee4d0693b2a129a6d291c1bc7ae97929c5ab54af3da31185672275167201->leave($__internal_9817ee4d0693b2a129a6d291c1bc7ae97929c5ab54af3da31185672275167201_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_row.html.php");
    }
}
