<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_b8a5d3a0a1c62d9a8d2ae471ea532df9938f13bbfd69dabfb5e88b3395fc1ed9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_99c3c133b57b394c078389a4c72c572385e7e0620337d1ae1f392f860964c736 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_99c3c133b57b394c078389a4c72c572385e7e0620337d1ae1f392f860964c736->enter($__internal_99c3c133b57b394c078389a4c72c572385e7e0620337d1ae1f392f860964c736_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        $__internal_0376dd0c4c2ebcb6b5b57182c8a5bcf5730340d9f1c5c08ff595e0d6a3d673dd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0376dd0c4c2ebcb6b5b57182c8a5bcf5730340d9f1c5c08ff595e0d6a3d673dd->enter($__internal_0376dd0c4c2ebcb6b5b57182c8a5bcf5730340d9f1c5c08ff595e0d6a3d673dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_99c3c133b57b394c078389a4c72c572385e7e0620337d1ae1f392f860964c736->leave($__internal_99c3c133b57b394c078389a4c72c572385e7e0620337d1ae1f392f860964c736_prof);

        
        $__internal_0376dd0c4c2ebcb6b5b57182c8a5bcf5730340d9f1c5c08ff595e0d6a3d673dd->leave($__internal_0376dd0c4c2ebcb6b5b57182c8a5bcf5730340d9f1c5c08ff595e0d6a3d673dd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
", "@Framework/Form/hidden_widget.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_widget.html.php");
    }
}
