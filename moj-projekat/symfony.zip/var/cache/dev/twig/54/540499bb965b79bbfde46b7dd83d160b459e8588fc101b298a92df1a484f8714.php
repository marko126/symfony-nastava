<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_26d13e3c47e5c2dfb27b1b8e4e739d72ec595ecaf38d03dd1df16df018f78d92 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d7df0cf1ff5844e2d4f413276c903fe00db75c1b7dae371da4f6464ea51ba62c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d7df0cf1ff5844e2d4f413276c903fe00db75c1b7dae371da4f6464ea51ba62c->enter($__internal_d7df0cf1ff5844e2d4f413276c903fe00db75c1b7dae371da4f6464ea51ba62c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_c0b5995d4189b0f766fed25428226aeb2b0d4281067a4dc3349c496dd879d28f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c0b5995d4189b0f766fed25428226aeb2b0d4281067a4dc3349c496dd879d28f->enter($__internal_c0b5995d4189b0f766fed25428226aeb2b0d4281067a4dc3349c496dd879d28f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d7df0cf1ff5844e2d4f413276c903fe00db75c1b7dae371da4f6464ea51ba62c->leave($__internal_d7df0cf1ff5844e2d4f413276c903fe00db75c1b7dae371da4f6464ea51ba62c_prof);

        
        $__internal_c0b5995d4189b0f766fed25428226aeb2b0d4281067a4dc3349c496dd879d28f->leave($__internal_c0b5995d4189b0f766fed25428226aeb2b0d4281067a4dc3349c496dd879d28f_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_353d714d84cfb8d1c7306e01cf8061a828a7a154d252d0ed2feca5bc885044d1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_353d714d84cfb8d1c7306e01cf8061a828a7a154d252d0ed2feca5bc885044d1->enter($__internal_353d714d84cfb8d1c7306e01cf8061a828a7a154d252d0ed2feca5bc885044d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_719f2f0c5b33b32a8af7f774d0636530b9d979033483f4f7dc1edea26829762f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_719f2f0c5b33b32a8af7f774d0636530b9d979033483f4f7dc1edea26829762f->enter($__internal_719f2f0c5b33b32a8af7f774d0636530b9d979033483f4f7dc1edea26829762f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_719f2f0c5b33b32a8af7f774d0636530b9d979033483f4f7dc1edea26829762f->leave($__internal_719f2f0c5b33b32a8af7f774d0636530b9d979033483f4f7dc1edea26829762f_prof);

        
        $__internal_353d714d84cfb8d1c7306e01cf8061a828a7a154d252d0ed2feca5bc885044d1->leave($__internal_353d714d84cfb8d1c7306e01cf8061a828a7a154d252d0ed2feca5bc885044d1_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_970918915b77501d3f7ce5c85e873e2ed11b82d37d715b13329029a6d866a290 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_970918915b77501d3f7ce5c85e873e2ed11b82d37d715b13329029a6d866a290->enter($__internal_970918915b77501d3f7ce5c85e873e2ed11b82d37d715b13329029a6d866a290_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_ed3991a0a77504779a08ea192fdc62743c9c3b0f5cdea14fbf4f40920b6743e5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed3991a0a77504779a08ea192fdc62743c9c3b0f5cdea14fbf4f40920b6743e5->enter($__internal_ed3991a0a77504779a08ea192fdc62743c9c3b0f5cdea14fbf4f40920b6743e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_ed3991a0a77504779a08ea192fdc62743c9c3b0f5cdea14fbf4f40920b6743e5->leave($__internal_ed3991a0a77504779a08ea192fdc62743c9c3b0f5cdea14fbf4f40920b6743e5_prof);

        
        $__internal_970918915b77501d3f7ce5c85e873e2ed11b82d37d715b13329029a6d866a290->leave($__internal_970918915b77501d3f7ce5c85e873e2ed11b82d37d715b13329029a6d866a290_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_143880ce8c53db6783640ab69e658d9764730e889f6f0b31176bdf0f43e6eb55 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_143880ce8c53db6783640ab69e658d9764730e889f6f0b31176bdf0f43e6eb55->enter($__internal_143880ce8c53db6783640ab69e658d9764730e889f6f0b31176bdf0f43e6eb55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_ad91b6d6dca37aa3aa86181544bcf0c95f9f5be580c2014365de4bb1f19ea99f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ad91b6d6dca37aa3aa86181544bcf0c95f9f5be580c2014365de4bb1f19ea99f->enter($__internal_ad91b6d6dca37aa3aa86181544bcf0c95f9f5be580c2014365de4bb1f19ea99f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_ad91b6d6dca37aa3aa86181544bcf0c95f9f5be580c2014365de4bb1f19ea99f->leave($__internal_ad91b6d6dca37aa3aa86181544bcf0c95f9f5be580c2014365de4bb1f19ea99f_prof);

        
        $__internal_143880ce8c53db6783640ab69e658d9764730e889f6f0b31176bdf0f43e6eb55->leave($__internal_143880ce8c53db6783640ab69e658d9764730e889f6f0b31176bdf0f43e6eb55_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
