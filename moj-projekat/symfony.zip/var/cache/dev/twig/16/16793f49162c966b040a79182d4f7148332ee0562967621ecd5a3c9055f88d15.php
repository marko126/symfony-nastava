<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_bc556f56c1b7e6fe99432ee659afae601c19abf01699c76bc8e37eb65f576e7b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6da974ae42dcd7285fa80a58902bfb0813a8f15b1b408f6dc39caa3e3abfb271 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6da974ae42dcd7285fa80a58902bfb0813a8f15b1b408f6dc39caa3e3abfb271->enter($__internal_6da974ae42dcd7285fa80a58902bfb0813a8f15b1b408f6dc39caa3e3abfb271_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        $__internal_f4cfd7e70524db24d2dacba5b64a82c352903e8cfca37b1cdf28c64398675632 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f4cfd7e70524db24d2dacba5b64a82c352903e8cfca37b1cdf28c64398675632->enter($__internal_f4cfd7e70524db24d2dacba5b64a82c352903e8cfca37b1cdf28c64398675632_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_6da974ae42dcd7285fa80a58902bfb0813a8f15b1b408f6dc39caa3e3abfb271->leave($__internal_6da974ae42dcd7285fa80a58902bfb0813a8f15b1b408f6dc39caa3e3abfb271_prof);

        
        $__internal_f4cfd7e70524db24d2dacba5b64a82c352903e8cfca37b1cdf28c64398675632->leave($__internal_f4cfd7e70524db24d2dacba5b64a82c352903e8cfca37b1cdf28c64398675632_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
", "@Framework/Form/integer_widget.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\integer_widget.html.php");
    }
}
