<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_e2776e3401f0cdf023dfa8ea58c59012751e60eed9360817af52c2b88690ff35 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_857fd006e552426585152e0ec41d14a8f417ce99138651d0650bdbc041d7a95d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_857fd006e552426585152e0ec41d14a8f417ce99138651d0650bdbc041d7a95d->enter($__internal_857fd006e552426585152e0ec41d14a8f417ce99138651d0650bdbc041d7a95d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        $__internal_97cf7eb5e9450a0721a12d6d7ce09f1a2e1f7b3a328f7673c59d7aec5247d5fc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_97cf7eb5e9450a0721a12d6d7ce09f1a2e1f7b3a328f7673c59d7aec5247d5fc->enter($__internal_97cf7eb5e9450a0721a12d6d7ce09f1a2e1f7b3a328f7673c59d7aec5247d5fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.rdf.twig", 1)->display($context);
        
        $__internal_857fd006e552426585152e0ec41d14a8f417ce99138651d0650bdbc041d7a95d->leave($__internal_857fd006e552426585152e0ec41d14a8f417ce99138651d0650bdbc041d7a95d_prof);

        
        $__internal_97cf7eb5e9450a0721a12d6d7ce09f1a2e1f7b3a328f7673c59d7aec5247d5fc->leave($__internal_97cf7eb5e9450a0721a12d6d7ce09f1a2e1f7b3a328f7673c59d7aec5247d5fc_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "@Twig/Exception/error.rdf.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.rdf.twig");
    }
}
