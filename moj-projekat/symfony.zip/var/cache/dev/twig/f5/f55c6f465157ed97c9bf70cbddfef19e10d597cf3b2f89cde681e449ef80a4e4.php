<?php

/* base.html.twig */
class __TwigTemplate_2097e98b38da415f61027b3de8ffa7df61e488a23f454f1bd86d2c32c03096b2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'header' => array($this, 'block_header'),
            'navigation' => array($this, 'block_navigation'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_df91326861d4c09df35f68542e31c8e95ea67feb8aa494e53a7cd764b954e268 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_df91326861d4c09df35f68542e31c8e95ea67feb8aa494e53a7cd764b954e268->enter($__internal_df91326861d4c09df35f68542e31c8e95ea67feb8aa494e53a7cd764b954e268_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_0f059783290e6bb13db6415fbe95ba8ca3cdf5d2d457a6d4c4090136e08c7f2b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0f059783290e6bb13db6415fbe95ba8ca3cdf5d2d457a6d4c4090136e08c7f2b->enter($__internal_0f059783290e6bb13db6415fbe95ba8ca3cdf5d2d457a6d4c4090136e08c7f2b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        
        ";
        // line 7
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 10
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"favicon.ico\" />
    </head>
    <body>
        ";
        // line 13
        $this->displayBlock('header', $context, $blocks);
        // line 16
        echo "        
        ";
        // line 17
        $this->displayBlock('navigation', $context, $blocks);
        // line 20
        echo "        
        ";
        // line 21
        $this->displayBlock('body', $context, $blocks);
        // line 24
        echo "        
        
        
        ";
        // line 27
        $this->displayBlock('javascripts', $context, $blocks);
        // line 28
        echo "    </body>
</html>
";
        
        $__internal_df91326861d4c09df35f68542e31c8e95ea67feb8aa494e53a7cd764b954e268->leave($__internal_df91326861d4c09df35f68542e31c8e95ea67feb8aa494e53a7cd764b954e268_prof);

        
        $__internal_0f059783290e6bb13db6415fbe95ba8ca3cdf5d2d457a6d4c4090136e08c7f2b->leave($__internal_0f059783290e6bb13db6415fbe95ba8ca3cdf5d2d457a6d4c4090136e08c7f2b_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_e0d3f3e0473268276f9e9c67522595e980173e417cd638205ca93dadeede6383 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e0d3f3e0473268276f9e9c67522595e980173e417cd638205ca93dadeede6383->enter($__internal_e0d3f3e0473268276f9e9c67522595e980173e417cd638205ca93dadeede6383_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_998cb74cf30b6a35a96b8266ff593e674e229e1f5f687e6cf34fd0e0446b6e0d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_998cb74cf30b6a35a96b8266ff593e674e229e1f5f687e6cf34fd0e0446b6e0d->enter($__internal_998cb74cf30b6a35a96b8266ff593e674e229e1f5f687e6cf34fd0e0446b6e0d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_998cb74cf30b6a35a96b8266ff593e674e229e1f5f687e6cf34fd0e0446b6e0d->leave($__internal_998cb74cf30b6a35a96b8266ff593e674e229e1f5f687e6cf34fd0e0446b6e0d_prof);

        
        $__internal_e0d3f3e0473268276f9e9c67522595e980173e417cd638205ca93dadeede6383->leave($__internal_e0d3f3e0473268276f9e9c67522595e980173e417cd638205ca93dadeede6383_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ae1430a15638e5faf2ac6da8e133c7531e6bb83d9f636689c0b98ec335a55d87 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ae1430a15638e5faf2ac6da8e133c7531e6bb83d9f636689c0b98ec335a55d87->enter($__internal_ae1430a15638e5faf2ac6da8e133c7531e6bb83d9f636689c0b98ec335a55d87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_15712a5a7a1ab3e386477b0b6d9a9b8d3f97c855e100eb853487963327444553 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_15712a5a7a1ab3e386477b0b6d9a9b8d3f97c855e100eb853487963327444553->enter($__internal_15712a5a7a1ab3e386477b0b6d9a9b8d3f97c855e100eb853487963327444553_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "            
        ";
        
        $__internal_15712a5a7a1ab3e386477b0b6d9a9b8d3f97c855e100eb853487963327444553->leave($__internal_15712a5a7a1ab3e386477b0b6d9a9b8d3f97c855e100eb853487963327444553_prof);

        
        $__internal_ae1430a15638e5faf2ac6da8e133c7531e6bb83d9f636689c0b98ec335a55d87->leave($__internal_ae1430a15638e5faf2ac6da8e133c7531e6bb83d9f636689c0b98ec335a55d87_prof);

    }

    // line 13
    public function block_header($context, array $blocks = array())
    {
        $__internal_8c560023154a700ec55948b2e63d69ab36375a914c56920e4c2b4703b4e87c33 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8c560023154a700ec55948b2e63d69ab36375a914c56920e4c2b4703b4e87c33->enter($__internal_8c560023154a700ec55948b2e63d69ab36375a914c56920e4c2b4703b4e87c33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_acb3eac8b1af546793072b2248b55dd24aff25b2976bc7d7c0fe5e168f91cc04 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_acb3eac8b1af546793072b2248b55dd24aff25b2976bc7d7c0fe5e168f91cc04->enter($__internal_acb3eac8b1af546793072b2248b55dd24aff25b2976bc7d7c0fe5e168f91cc04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 14
        echo "            
        ";
        
        $__internal_acb3eac8b1af546793072b2248b55dd24aff25b2976bc7d7c0fe5e168f91cc04->leave($__internal_acb3eac8b1af546793072b2248b55dd24aff25b2976bc7d7c0fe5e168f91cc04_prof);

        
        $__internal_8c560023154a700ec55948b2e63d69ab36375a914c56920e4c2b4703b4e87c33->leave($__internal_8c560023154a700ec55948b2e63d69ab36375a914c56920e4c2b4703b4e87c33_prof);

    }

    // line 17
    public function block_navigation($context, array $blocks = array())
    {
        $__internal_5a58f17343a06f857221547fb5049579382d38e300be37a21ed6585a2c777536 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5a58f17343a06f857221547fb5049579382d38e300be37a21ed6585a2c777536->enter($__internal_5a58f17343a06f857221547fb5049579382d38e300be37a21ed6585a2c777536_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navigation"));

        $__internal_9cceb3990a03f6132bb017c310f13d0d607d991b867056fc8ecf8d216889bae1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9cceb3990a03f6132bb017c310f13d0d607d991b867056fc8ecf8d216889bae1->enter($__internal_9cceb3990a03f6132bb017c310f13d0d607d991b867056fc8ecf8d216889bae1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navigation"));

        // line 18
        echo "            
        ";
        
        $__internal_9cceb3990a03f6132bb017c310f13d0d607d991b867056fc8ecf8d216889bae1->leave($__internal_9cceb3990a03f6132bb017c310f13d0d607d991b867056fc8ecf8d216889bae1_prof);

        
        $__internal_5a58f17343a06f857221547fb5049579382d38e300be37a21ed6585a2c777536->leave($__internal_5a58f17343a06f857221547fb5049579382d38e300be37a21ed6585a2c777536_prof);

    }

    // line 21
    public function block_body($context, array $blocks = array())
    {
        $__internal_4e4551024b1a4dd8fbc5af2d40f65fd5e4360cbc1d0bbacdbfb3587d3bea8843 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4e4551024b1a4dd8fbc5af2d40f65fd5e4360cbc1d0bbacdbfb3587d3bea8843->enter($__internal_4e4551024b1a4dd8fbc5af2d40f65fd5e4360cbc1d0bbacdbfb3587d3bea8843_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b238fc1a5ec94dcb8f25031705bc340a8cac5e87dc8140caedec8adb725ecfdf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b238fc1a5ec94dcb8f25031705bc340a8cac5e87dc8140caedec8adb725ecfdf->enter($__internal_b238fc1a5ec94dcb8f25031705bc340a8cac5e87dc8140caedec8adb725ecfdf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 22
        echo "            
        ";
        
        $__internal_b238fc1a5ec94dcb8f25031705bc340a8cac5e87dc8140caedec8adb725ecfdf->leave($__internal_b238fc1a5ec94dcb8f25031705bc340a8cac5e87dc8140caedec8adb725ecfdf_prof);

        
        $__internal_4e4551024b1a4dd8fbc5af2d40f65fd5e4360cbc1d0bbacdbfb3587d3bea8843->leave($__internal_4e4551024b1a4dd8fbc5af2d40f65fd5e4360cbc1d0bbacdbfb3587d3bea8843_prof);

    }

    // line 27
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_8b676d98d64ef24485f3fab3fb069be2a41bfa97ba3b1e7135f314f62afeb788 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8b676d98d64ef24485f3fab3fb069be2a41bfa97ba3b1e7135f314f62afeb788->enter($__internal_8b676d98d64ef24485f3fab3fb069be2a41bfa97ba3b1e7135f314f62afeb788_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_ecd6af4dc944cf7f20695469e85de060c55a2d92bd846d77011ea2c698838ba9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ecd6af4dc944cf7f20695469e85de060c55a2d92bd846d77011ea2c698838ba9->enter($__internal_ecd6af4dc944cf7f20695469e85de060c55a2d92bd846d77011ea2c698838ba9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_ecd6af4dc944cf7f20695469e85de060c55a2d92bd846d77011ea2c698838ba9->leave($__internal_ecd6af4dc944cf7f20695469e85de060c55a2d92bd846d77011ea2c698838ba9_prof);

        
        $__internal_8b676d98d64ef24485f3fab3fb069be2a41bfa97ba3b1e7135f314f62afeb788->leave($__internal_8b676d98d64ef24485f3fab3fb069be2a41bfa97ba3b1e7135f314f62afeb788_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  178 => 27,  167 => 22,  158 => 21,  147 => 18,  138 => 17,  127 => 14,  118 => 13,  107 => 8,  98 => 7,  80 => 5,  68 => 28,  66 => 27,  61 => 24,  59 => 21,  56 => 20,  54 => 17,  51 => 16,  49 => 13,  44 => 10,  42 => 7,  37 => 5,  31 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        
        {% block stylesheets %}
            
        {% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"favicon.ico\" />
    </head>
    <body>
        {% block header %}
            
        {% endblock %}
        
        {% block navigation %}
            
        {% endblock %}
        
        {% block body %}
            
        {% endblock %}
        
        
        
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\app\\Resources\\views\\base.html.twig");
    }
}
