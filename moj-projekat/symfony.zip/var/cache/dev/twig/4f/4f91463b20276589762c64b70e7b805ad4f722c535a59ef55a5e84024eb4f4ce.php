<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_a1adb9c526d41f20d2d4ffe5f67805d06b7ab498cebc6efcc533b82a65d19229 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9749c021f5d7f86e32454fc2aeedf007101eaf301c6593ba3482087792064a92 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9749c021f5d7f86e32454fc2aeedf007101eaf301c6593ba3482087792064a92->enter($__internal_9749c021f5d7f86e32454fc2aeedf007101eaf301c6593ba3482087792064a92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        $__internal_5bc3402e8a6d76308af715dbc6756011aa5adb0672c31e74422581db4528c4d6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5bc3402e8a6d76308af715dbc6756011aa5adb0672c31e74422581db4528c4d6->enter($__internal_5bc3402e8a6d76308af715dbc6756011aa5adb0672c31e74422581db4528c4d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_9749c021f5d7f86e32454fc2aeedf007101eaf301c6593ba3482087792064a92->leave($__internal_9749c021f5d7f86e32454fc2aeedf007101eaf301c6593ba3482087792064a92_prof);

        
        $__internal_5bc3402e8a6d76308af715dbc6756011aa5adb0672c31e74422581db4528c4d6->leave($__internal_5bc3402e8a6d76308af715dbc6756011aa5adb0672c31e74422581db4528c4d6_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.atom.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
