<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_ba958de71b093b006153a7926b9cb231713e11d101337254122c80b49c716efa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2ee4175e8dc5080c008c0cb44a52c0e43a08d90cc69485574e6d24ff641d8f96 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2ee4175e8dc5080c008c0cb44a52c0e43a08d90cc69485574e6d24ff641d8f96->enter($__internal_2ee4175e8dc5080c008c0cb44a52c0e43a08d90cc69485574e6d24ff641d8f96_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        $__internal_e188f6f34430873c39a01ba9878b9fa76b65df5ef4baddfec16c5a904ac5a2c4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e188f6f34430873c39a01ba9878b9fa76b65df5ef4baddfec16c5a904ac5a2c4->enter($__internal_e188f6f34430873c39a01ba9878b9fa76b65df5ef4baddfec16c5a904ac5a2c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_2ee4175e8dc5080c008c0cb44a52c0e43a08d90cc69485574e6d24ff641d8f96->leave($__internal_2ee4175e8dc5080c008c0cb44a52c0e43a08d90cc69485574e6d24ff641d8f96_prof);

        
        $__internal_e188f6f34430873c39a01ba9878b9fa76b65df5ef4baddfec16c5a904ac5a2c4->leave($__internal_e188f6f34430873c39a01ba9878b9fa76b65df5ef4baddfec16c5a904ac5a2c4_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.css.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.css.twig");
    }
}
