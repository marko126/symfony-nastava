<?php

/* @Twig/Exception/traces.txt.twig */
class __TwigTemplate_219559ce79b89b5f770f414bac4c00f0e28337f2b0d0d4b0dd1c6b4579ff4cc7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_458d6a9d20c78ea1c0ef8c333ed1d5242d91feefef47e3457839bd2cb3fdb5e7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_458d6a9d20c78ea1c0ef8c333ed1d5242d91feefef47e3457839bd2cb3fdb5e7->enter($__internal_458d6a9d20c78ea1c0ef8c333ed1d5242d91feefef47e3457839bd2cb3fdb5e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/traces.txt.twig"));

        $__internal_d7965defcc50732dc9f8914ee287ee820b0ec503644ce8a7cb7f895ed1899ace = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d7965defcc50732dc9f8914ee287ee820b0ec503644ce8a7cb7f895ed1899ace->enter($__internal_d7965defcc50732dc9f8914ee287ee820b0ec503644ce8a7cb7f895ed1899ace_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/traces.txt.twig"));

        // line 1
        if (twig_length_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "trace", array()))) {
            // line 2
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "trace", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["trace"]) {
                // line 3
                $this->loadTemplate("@Twig/Exception/trace.txt.twig", "@Twig/Exception/traces.txt.twig", 3)->display(array("trace" => $context["trace"]));
                // line 4
                echo "
";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['trace'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        
        $__internal_458d6a9d20c78ea1c0ef8c333ed1d5242d91feefef47e3457839bd2cb3fdb5e7->leave($__internal_458d6a9d20c78ea1c0ef8c333ed1d5242d91feefef47e3457839bd2cb3fdb5e7_prof);

        
        $__internal_d7965defcc50732dc9f8914ee287ee820b0ec503644ce8a7cb7f895ed1899ace->leave($__internal_d7965defcc50732dc9f8914ee287ee820b0ec503644ce8a7cb7f895ed1899ace_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/traces.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 4,  31 => 3,  27 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if exception.trace|length %}
{% for trace in exception.trace %}
{% include '@Twig/Exception/trace.txt.twig' with { 'trace': trace } only %}

{% endfor %}
{% endif %}
", "@Twig/Exception/traces.txt.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\traces.txt.twig");
    }
}
