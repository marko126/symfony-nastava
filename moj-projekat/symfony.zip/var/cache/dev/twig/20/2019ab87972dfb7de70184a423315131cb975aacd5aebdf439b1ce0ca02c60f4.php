<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_e0ae0dee3603c7fd9cdae934370e4f0edb2b447108fc97cce36a0288c90af8de extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ba7f3be312eaa0d771e791c1ee1c92a90144a0651965f241bc5c3923580d5d83 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ba7f3be312eaa0d771e791c1ee1c92a90144a0651965f241bc5c3923580d5d83->enter($__internal_ba7f3be312eaa0d771e791c1ee1c92a90144a0651965f241bc5c3923580d5d83_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        $__internal_1d51d02083ce8c38327d9a8045d73fa668997c36ea114ba58f41e0e1971c2d6c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1d51d02083ce8c38327d9a8045d73fa668997c36ea114ba58f41e0e1971c2d6c->enter($__internal_1d51d02083ce8c38327d9a8045d73fa668997c36ea114ba58f41e0e1971c2d6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_ba7f3be312eaa0d771e791c1ee1c92a90144a0651965f241bc5c3923580d5d83->leave($__internal_ba7f3be312eaa0d771e791c1ee1c92a90144a0651965f241bc5c3923580d5d83_prof);

        
        $__internal_1d51d02083ce8c38327d9a8045d73fa668997c36ea114ba58f41e0e1971c2d6c->leave($__internal_1d51d02083ce8c38327d9a8045d73fa668997c36ea114ba58f41e0e1971c2d6c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\password_widget.html.php");
    }
}
