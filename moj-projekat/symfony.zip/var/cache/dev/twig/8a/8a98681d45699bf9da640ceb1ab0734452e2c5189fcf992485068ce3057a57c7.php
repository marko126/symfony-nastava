<?php

/* ::base.html.twig */
class __TwigTemplate_169220fa430e204c23341620f6df8caef35f129c3d0290146c23bf85fc6da608 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_88730e2b069d8946032c843a7cd5d4849f1d6c93b62fc7061e21b82badf0a861 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_88730e2b069d8946032c843a7cd5d4849f1d6c93b62fc7061e21b82badf0a861->enter($__internal_88730e2b069d8946032c843a7cd5d4849f1d6c93b62fc7061e21b82badf0a861_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        $__internal_d8b49ea1f8b97b876a42a568bcce620358218bd324dd8cf7d27bacf87ae74292 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d8b49ea1f8b97b876a42a568bcce620358218bd324dd8cf7d27bacf87ae74292->enter($__internal_d8b49ea1f8b97b876a42a568bcce620358218bd324dd8cf7d27bacf87ae74292_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_88730e2b069d8946032c843a7cd5d4849f1d6c93b62fc7061e21b82badf0a861->leave($__internal_88730e2b069d8946032c843a7cd5d4849f1d6c93b62fc7061e21b82badf0a861_prof);

        
        $__internal_d8b49ea1f8b97b876a42a568bcce620358218bd324dd8cf7d27bacf87ae74292->leave($__internal_d8b49ea1f8b97b876a42a568bcce620358218bd324dd8cf7d27bacf87ae74292_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_24956fdd06dae00854951feb084d9f52f59d93a7230b6a071285b03ee382f300 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_24956fdd06dae00854951feb084d9f52f59d93a7230b6a071285b03ee382f300->enter($__internal_24956fdd06dae00854951feb084d9f52f59d93a7230b6a071285b03ee382f300_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_6d36a22b059fdf2f86881f5de0b0be9581e6ab0b3dcbc7db1ba9ae984fb5ac1b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d36a22b059fdf2f86881f5de0b0be9581e6ab0b3dcbc7db1ba9ae984fb5ac1b->enter($__internal_6d36a22b059fdf2f86881f5de0b0be9581e6ab0b3dcbc7db1ba9ae984fb5ac1b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_6d36a22b059fdf2f86881f5de0b0be9581e6ab0b3dcbc7db1ba9ae984fb5ac1b->leave($__internal_6d36a22b059fdf2f86881f5de0b0be9581e6ab0b3dcbc7db1ba9ae984fb5ac1b_prof);

        
        $__internal_24956fdd06dae00854951feb084d9f52f59d93a7230b6a071285b03ee382f300->leave($__internal_24956fdd06dae00854951feb084d9f52f59d93a7230b6a071285b03ee382f300_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_85330fe2e70b9a9f6d07f2cf03cd4bb680fc01634327c36a1a267b2fe88134b8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_85330fe2e70b9a9f6d07f2cf03cd4bb680fc01634327c36a1a267b2fe88134b8->enter($__internal_85330fe2e70b9a9f6d07f2cf03cd4bb680fc01634327c36a1a267b2fe88134b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_cd14ee6f0bb9f960927f0c7860bf0cc83261295a2ba2c661b7b1eac405fb259d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd14ee6f0bb9f960927f0c7860bf0cc83261295a2ba2c661b7b1eac405fb259d->enter($__internal_cd14ee6f0bb9f960927f0c7860bf0cc83261295a2ba2c661b7b1eac405fb259d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_cd14ee6f0bb9f960927f0c7860bf0cc83261295a2ba2c661b7b1eac405fb259d->leave($__internal_cd14ee6f0bb9f960927f0c7860bf0cc83261295a2ba2c661b7b1eac405fb259d_prof);

        
        $__internal_85330fe2e70b9a9f6d07f2cf03cd4bb680fc01634327c36a1a267b2fe88134b8->leave($__internal_85330fe2e70b9a9f6d07f2cf03cd4bb680fc01634327c36a1a267b2fe88134b8_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_6553ed1fd037f71ba915dec4cfbb0ab06d070692c6968bfeb2b93ae5c70bd6ba = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6553ed1fd037f71ba915dec4cfbb0ab06d070692c6968bfeb2b93ae5c70bd6ba->enter($__internal_6553ed1fd037f71ba915dec4cfbb0ab06d070692c6968bfeb2b93ae5c70bd6ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_c67668bbff2b471de31a6598322617c8b414f36390136c37b3e7db10d35612ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c67668bbff2b471de31a6598322617c8b414f36390136c37b3e7db10d35612ba->enter($__internal_c67668bbff2b471de31a6598322617c8b414f36390136c37b3e7db10d35612ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_c67668bbff2b471de31a6598322617c8b414f36390136c37b3e7db10d35612ba->leave($__internal_c67668bbff2b471de31a6598322617c8b414f36390136c37b3e7db10d35612ba_prof);

        
        $__internal_6553ed1fd037f71ba915dec4cfbb0ab06d070692c6968bfeb2b93ae5c70bd6ba->leave($__internal_6553ed1fd037f71ba915dec4cfbb0ab06d070692c6968bfeb2b93ae5c70bd6ba_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_568b8ccb56fad1bc048e3fef7402aade64818899b9f7319f18d745ac372a753d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_568b8ccb56fad1bc048e3fef7402aade64818899b9f7319f18d745ac372a753d->enter($__internal_568b8ccb56fad1bc048e3fef7402aade64818899b9f7319f18d745ac372a753d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_77f2b10f5e35f13089085d44f400ecf5856333eb52564755dbe0b0dd2adcae79 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_77f2b10f5e35f13089085d44f400ecf5856333eb52564755dbe0b0dd2adcae79->enter($__internal_77f2b10f5e35f13089085d44f400ecf5856333eb52564755dbe0b0dd2adcae79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_77f2b10f5e35f13089085d44f400ecf5856333eb52564755dbe0b0dd2adcae79->leave($__internal_77f2b10f5e35f13089085d44f400ecf5856333eb52564755dbe0b0dd2adcae79_prof);

        
        $__internal_568b8ccb56fad1bc048e3fef7402aade64818899b9f7319f18d745ac372a753d->leave($__internal_568b8ccb56fad1bc048e3fef7402aade64818899b9f7319f18d745ac372a753d_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "::base.html.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\app/Resources\\views/base.html.twig");
    }
}
