<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_75b4cd5820cc560712bad67b3348823a1abeb258ce544d1564f2d7341a407de9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4fa51f52fbb66c7c0a3e160eca28d76bc46da94814dd135a1efc5ae8cf2267cb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4fa51f52fbb66c7c0a3e160eca28d76bc46da94814dd135a1efc5ae8cf2267cb->enter($__internal_4fa51f52fbb66c7c0a3e160eca28d76bc46da94814dd135a1efc5ae8cf2267cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        $__internal_53912db48854b992e65f11d5df2dbdf2108d31e6dd255afdff189c13f0c44fa2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_53912db48854b992e65f11d5df2dbdf2108d31e6dd255afdff189c13f0c44fa2->enter($__internal_53912db48854b992e65f11d5df2dbdf2108d31e6dd255afdff189c13f0c44fa2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_4fa51f52fbb66c7c0a3e160eca28d76bc46da94814dd135a1efc5ae8cf2267cb->leave($__internal_4fa51f52fbb66c7c0a3e160eca28d76bc46da94814dd135a1efc5ae8cf2267cb_prof);

        
        $__internal_53912db48854b992e65f11d5df2dbdf2108d31e6dd255afdff189c13f0c44fa2->leave($__internal_53912db48854b992e65f11d5df2dbdf2108d31e6dd255afdff189c13f0c44fa2_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.rdf.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
