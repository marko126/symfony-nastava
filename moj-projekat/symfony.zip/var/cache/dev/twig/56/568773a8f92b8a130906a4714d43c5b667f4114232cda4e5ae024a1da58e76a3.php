<?php

/* @Twig/Exception/error.css.twig */
class __TwigTemplate_038dc8b367b43f7f5a3258afa18c40908ee2574ab8fb8dfd1965474870cc90dc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_effeb08922380f3d176dc18076ca842b9a5c0774c18d485870b5489ab124ed21 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_effeb08922380f3d176dc18076ca842b9a5c0774c18d485870b5489ab124ed21->enter($__internal_effeb08922380f3d176dc18076ca842b9a5c0774c18d485870b5489ab124ed21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        $__internal_6e8e19a4b01ce67ada5cc591dd3259dd63401d15584064b1b20df46374e04ec5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6e8e19a4b01ce67ada5cc591dd3259dd63401d15584064b1b20df46374e04ec5->enter($__internal_6e8e19a4b01ce67ada5cc591dd3259dd63401d15584064b1b20df46374e04ec5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_effeb08922380f3d176dc18076ca842b9a5c0774c18d485870b5489ab124ed21->leave($__internal_effeb08922380f3d176dc18076ca842b9a5c0774c18d485870b5489ab124ed21_prof);

        
        $__internal_6e8e19a4b01ce67ada5cc591dd3259dd63401d15584064b1b20df46374e04ec5->leave($__internal_6e8e19a4b01ce67ada5cc591dd3259dd63401d15584064b1b20df46374e04ec5_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "@Twig/Exception/error.css.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.css.twig");
    }
}
