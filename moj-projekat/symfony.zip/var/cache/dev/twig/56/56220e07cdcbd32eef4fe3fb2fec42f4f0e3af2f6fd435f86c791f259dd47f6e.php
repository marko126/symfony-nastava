<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_2e4bee912c8e746a69c68a968dc6c6de1f29297d719333f47a83f309de633b24 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d196fc25ecad9327a2b2eed1eb6e87dd96973f4407a62f2253a30ec50daa45ab = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d196fc25ecad9327a2b2eed1eb6e87dd96973f4407a62f2253a30ec50daa45ab->enter($__internal_d196fc25ecad9327a2b2eed1eb6e87dd96973f4407a62f2253a30ec50daa45ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        $__internal_33eb60dd08ab640c704d61340747216989bd990fc4690de41ada2f0dcf7683d6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_33eb60dd08ab640c704d61340747216989bd990fc4690de41ada2f0dcf7683d6->enter($__internal_33eb60dd08ab640c704d61340747216989bd990fc4690de41ada2f0dcf7683d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_d196fc25ecad9327a2b2eed1eb6e87dd96973f4407a62f2253a30ec50daa45ab->leave($__internal_d196fc25ecad9327a2b2eed1eb6e87dd96973f4407a62f2253a30ec50daa45ab_prof);

        
        $__internal_33eb60dd08ab640c704d61340747216989bd990fc4690de41ada2f0dcf7683d6->leave($__internal_33eb60dd08ab640c704d61340747216989bd990fc4690de41ada2f0dcf7683d6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/form_row.html.php", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\form_row.html.php");
    }
}
