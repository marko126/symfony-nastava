<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_95414630f54c0fe9c572bd52f7ac329b063dd77b6d2c72abe7635fd4b79a5675 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_562f01fbf625f93d46c189abe0d53f113c9c2dc2c9e35c224ab1f32bd0ba98fe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_562f01fbf625f93d46c189abe0d53f113c9c2dc2c9e35c224ab1f32bd0ba98fe->enter($__internal_562f01fbf625f93d46c189abe0d53f113c9c2dc2c9e35c224ab1f32bd0ba98fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_b271c2fd99f278a1b8df3d146bb2c7923971b9421c0dd3ae18275282127ea4c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b271c2fd99f278a1b8df3d146bb2c7923971b9421c0dd3ae18275282127ea4c5->enter($__internal_b271c2fd99f278a1b8df3d146bb2c7923971b9421c0dd3ae18275282127ea4c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_562f01fbf625f93d46c189abe0d53f113c9c2dc2c9e35c224ab1f32bd0ba98fe->leave($__internal_562f01fbf625f93d46c189abe0d53f113c9c2dc2c9e35c224ab1f32bd0ba98fe_prof);

        
        $__internal_b271c2fd99f278a1b8df3d146bb2c7923971b9421c0dd3ae18275282127ea4c5->leave($__internal_b271c2fd99f278a1b8df3d146bb2c7923971b9421c0dd3ae18275282127ea4c5_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_f72aded2a3ee0cbced6dcd019c8e66f17f9a88bb625bba4e3951ca760452a597 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f72aded2a3ee0cbced6dcd019c8e66f17f9a88bb625bba4e3951ca760452a597->enter($__internal_f72aded2a3ee0cbced6dcd019c8e66f17f9a88bb625bba4e3951ca760452a597_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_ad83c41f7cc6ad5408136870c8f6fb0423ba0a93d0f5d59602f210d6580d7ce4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ad83c41f7cc6ad5408136870c8f6fb0423ba0a93d0f5d59602f210d6580d7ce4->enter($__internal_ad83c41f7cc6ad5408136870c8f6fb0423ba0a93d0f5d59602f210d6580d7ce4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_ad83c41f7cc6ad5408136870c8f6fb0423ba0a93d0f5d59602f210d6580d7ce4->leave($__internal_ad83c41f7cc6ad5408136870c8f6fb0423ba0a93d0f5d59602f210d6580d7ce4_prof);

        
        $__internal_f72aded2a3ee0cbced6dcd019c8e66f17f9a88bb625bba4e3951ca760452a597->leave($__internal_f72aded2a3ee0cbced6dcd019c8e66f17f9a88bb625bba4e3951ca760452a597_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_be062b8d5fa8810d2ef4c9694a37ee5c794cfdb424d4963e1797910e047e5d8d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_be062b8d5fa8810d2ef4c9694a37ee5c794cfdb424d4963e1797910e047e5d8d->enter($__internal_be062b8d5fa8810d2ef4c9694a37ee5c794cfdb424d4963e1797910e047e5d8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_79fc447611dce1dabc9806f7bb72adcf625a96e71bf413cf664a46502f0414a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_79fc447611dce1dabc9806f7bb72adcf625a96e71bf413cf664a46502f0414a9->enter($__internal_79fc447611dce1dabc9806f7bb72adcf625a96e71bf413cf664a46502f0414a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_79fc447611dce1dabc9806f7bb72adcf625a96e71bf413cf664a46502f0414a9->leave($__internal_79fc447611dce1dabc9806f7bb72adcf625a96e71bf413cf664a46502f0414a9_prof);

        
        $__internal_be062b8d5fa8810d2ef4c9694a37ee5c794cfdb424d4963e1797910e047e5d8d->leave($__internal_be062b8d5fa8810d2ef4c9694a37ee5c794cfdb424d4963e1797910e047e5d8d_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_97e6825692dd22efb8a154f2e786d336923823879dac9a9b71235d297a22361a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_97e6825692dd22efb8a154f2e786d336923823879dac9a9b71235d297a22361a->enter($__internal_97e6825692dd22efb8a154f2e786d336923823879dac9a9b71235d297a22361a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_1d70c9dd774d9ab814b82cc25ffccf4aa873708890de5f125865ba66fce21847 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1d70c9dd774d9ab814b82cc25ffccf4aa873708890de5f125865ba66fce21847->enter($__internal_1d70c9dd774d9ab814b82cc25ffccf4aa873708890de5f125865ba66fce21847_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_1d70c9dd774d9ab814b82cc25ffccf4aa873708890de5f125865ba66fce21847->leave($__internal_1d70c9dd774d9ab814b82cc25ffccf4aa873708890de5f125865ba66fce21847_prof);

        
        $__internal_97e6825692dd22efb8a154f2e786d336923823879dac9a9b71235d297a22361a->leave($__internal_97e6825692dd22efb8a154f2e786d336923823879dac9a9b71235d297a22361a_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
