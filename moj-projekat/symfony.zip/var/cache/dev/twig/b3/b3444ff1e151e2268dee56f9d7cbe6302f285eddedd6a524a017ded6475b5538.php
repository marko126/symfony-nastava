<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_95414630f54c0fe9c572bd52f7ac329b063dd77b6d2c72abe7635fd4b79a5675 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d56b08ceffdfe3e79bef68f625de85ea6ab0a07a62b7e4ab6bb4d006341d5a82 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d56b08ceffdfe3e79bef68f625de85ea6ab0a07a62b7e4ab6bb4d006341d5a82->enter($__internal_d56b08ceffdfe3e79bef68f625de85ea6ab0a07a62b7e4ab6bb4d006341d5a82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_196c9620283548e522e8f7f569435e28b2d9d39a5f1af8254fff7fd1b3675634 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_196c9620283548e522e8f7f569435e28b2d9d39a5f1af8254fff7fd1b3675634->enter($__internal_196c9620283548e522e8f7f569435e28b2d9d39a5f1af8254fff7fd1b3675634_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d56b08ceffdfe3e79bef68f625de85ea6ab0a07a62b7e4ab6bb4d006341d5a82->leave($__internal_d56b08ceffdfe3e79bef68f625de85ea6ab0a07a62b7e4ab6bb4d006341d5a82_prof);

        
        $__internal_196c9620283548e522e8f7f569435e28b2d9d39a5f1af8254fff7fd1b3675634->leave($__internal_196c9620283548e522e8f7f569435e28b2d9d39a5f1af8254fff7fd1b3675634_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_a2c26cbcfd01fb62c7b33c38a4c98cea83b4a4dcc856c03c394409823a45e030 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a2c26cbcfd01fb62c7b33c38a4c98cea83b4a4dcc856c03c394409823a45e030->enter($__internal_a2c26cbcfd01fb62c7b33c38a4c98cea83b4a4dcc856c03c394409823a45e030_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_450ace7ae2361c0549a99d15d882041148066aed668043e0d2b30d5993925b66 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_450ace7ae2361c0549a99d15d882041148066aed668043e0d2b30d5993925b66->enter($__internal_450ace7ae2361c0549a99d15d882041148066aed668043e0d2b30d5993925b66_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_450ace7ae2361c0549a99d15d882041148066aed668043e0d2b30d5993925b66->leave($__internal_450ace7ae2361c0549a99d15d882041148066aed668043e0d2b30d5993925b66_prof);

        
        $__internal_a2c26cbcfd01fb62c7b33c38a4c98cea83b4a4dcc856c03c394409823a45e030->leave($__internal_a2c26cbcfd01fb62c7b33c38a4c98cea83b4a4dcc856c03c394409823a45e030_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_f91937f2303439d86588a80e7932860a92440f4fdfe6db9545d38cc06d3cff71 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f91937f2303439d86588a80e7932860a92440f4fdfe6db9545d38cc06d3cff71->enter($__internal_f91937f2303439d86588a80e7932860a92440f4fdfe6db9545d38cc06d3cff71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_ff138d304def627957aef3a4e8d2cb3628937eddb7b9f5e2d6a01c6199c36707 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ff138d304def627957aef3a4e8d2cb3628937eddb7b9f5e2d6a01c6199c36707->enter($__internal_ff138d304def627957aef3a4e8d2cb3628937eddb7b9f5e2d6a01c6199c36707_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_ff138d304def627957aef3a4e8d2cb3628937eddb7b9f5e2d6a01c6199c36707->leave($__internal_ff138d304def627957aef3a4e8d2cb3628937eddb7b9f5e2d6a01c6199c36707_prof);

        
        $__internal_f91937f2303439d86588a80e7932860a92440f4fdfe6db9545d38cc06d3cff71->leave($__internal_f91937f2303439d86588a80e7932860a92440f4fdfe6db9545d38cc06d3cff71_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_511a2b2b24b2fa3a7a370f9bfaff97b25845d096631917d0a20bec68dd5bc17e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_511a2b2b24b2fa3a7a370f9bfaff97b25845d096631917d0a20bec68dd5bc17e->enter($__internal_511a2b2b24b2fa3a7a370f9bfaff97b25845d096631917d0a20bec68dd5bc17e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_7c9a1af24ed9e7a6ea787a8c88f7476724f2da4359a70f43af8644d0064bfa62 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c9a1af24ed9e7a6ea787a8c88f7476724f2da4359a70f43af8644d0064bfa62->enter($__internal_7c9a1af24ed9e7a6ea787a8c88f7476724f2da4359a70f43af8644d0064bfa62_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_7c9a1af24ed9e7a6ea787a8c88f7476724f2da4359a70f43af8644d0064bfa62->leave($__internal_7c9a1af24ed9e7a6ea787a8c88f7476724f2da4359a70f43af8644d0064bfa62_prof);

        
        $__internal_511a2b2b24b2fa3a7a370f9bfaff97b25845d096631917d0a20bec68dd5bc17e->leave($__internal_511a2b2b24b2fa3a7a370f9bfaff97b25845d096631917d0a20bec68dd5bc17e_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\wamp\\www\\symfony-nastava\\moj-projekat\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
