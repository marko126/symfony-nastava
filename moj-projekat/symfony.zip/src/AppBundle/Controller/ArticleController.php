<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Article;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;

class ArticleController extends Controller {
    
    public $artikli = [
            0 => [
                'id' => 1,
                'title' => 'Lopta',
                'author' => 'Marko'
            ],
            1 => [
                'id' => 2,
                'title' => 'Laptop',
                'author' => 'Marko'
            ],
            2 => [
                'id' => 3,
                'title' => 'Tabla',
                'author' => 'Marko'
            ],
            3 => [
                'id' => 4,
                'title' => 'Televizor',
                'author' => 'Marko'
            ],
        ];
    
    public function listAction($page = 1, $_locale = "sr", $_format = "html") {
        
        switch ($_locale) {
            case "sr":
                $text = "Листа артикала, страна број ".$page;
                break;
            case "en":
                $text = "List of articles, page nr. ".$page;
                break;
            case "de":
                $text = "List von Artikeln, Seitenzahl ".$page;
                break;
        }
        
        $repository = $this->getDoctrine()->getRepository('AppBundle:Article');
        
        $query = $repository->createQueryBuilder('a')
                ->where('a.price < 100000000')
                ->orderBy('a.name', 'DESC')
                ->getQuery();
        
        $artikli = $query->getResult();
        
        return $this->render('article/list.html.twig', [
            'text' => $text,
            'artikli' => $artikli
        ]);
        
    }
    
    
    public function showAction($id, $name) {
        
        //$artikal = $this->findArticleByTitle($name);
        
        $em = $this->getDoctrine()->getManager();
        
        $query = $em->createQuery(
                'SELECT a
                 FROM AppBundle:Article a
                 WHERE a.id = :id
                '
        )->setParameter('id', $id);
        
        $artikal = $query->setMaxResults(1)->getOneOrNullResult();
        
        if (!$artikal) {
            throw new Exception;
        }
        
        return $this->render('article/show.html.twig', ['artikal' => $artikal]);
        
    }
    
    public function createAction() {
        /*
        $article = new Article();
        $article->setName('Stolica');
        $article->setCategory('Nameštaj');
        $article->setPrice(10);
        
        $em = $this->getDoctrine()->getManager();
        
        $em->persist($article);
        $em->flush();
        
        return new Response('Uspešno ste uneli novi artikal '.$article->getName());
        */
    }
    
    public function updateAction($id) {
        /*
        // Pozivamo entity manager
        $em = $this->getDoctrine()->getManager();
        
        // Pozivamo repozitorijum za entity Article
        $repository = $em->getRepository('AppBundle:Article');
        
        // Prikupljamo objekat entity klase Article
        $article = $repository->find($id);
        
        // Vracamo staru cenu
        $old_price = $article->getPrice();
        
        // Menjamo podatke o ceni
        $article->setPrice(20);
        
        // Upisujemo podatke u bazu
        $em->flush();
        */
        
        // Korišćenje DQL-a
        
        $em = $this->getDoctrine()->getManager();
        
        $query = $em->createQuery(
                'UPDATE AppBundle:Article a
                 SET a.price = :price
                 WHERE a.id = :id
                '
        )->setParameter('price', 6)
         ->setParameter('id', $id);
        
        $article = $query->getResult();
        
        $em->flush();
        
        return new Response('Upsešno je izmenjena cena za artikal ');
        
    }
    
    public function findArticleByTitle($title) {
        foreach ($this->artikli as $artikal) {
            if (in_array($title, $artikal)) {
                return $artikal;
            }
        }
        return false;
    }
    
}

